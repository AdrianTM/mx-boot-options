<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="141"/>
        <source>Administrator Access Required</source>
        <translation>Beheerdersrechten Vereist</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="142"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Voor deze bewerking zijn beheerdersrechten vereist. Start de toepassing opnieuw op en voer uw wachtwoord in wanneer daarom wordt gevraagd.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Live omgeving gedetecteerd. Selecteer aub de root partitie van het
systeem dat u wilt wijzigen (alleen Linux partities worden weergegeven)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Ongedaan maken</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opties</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Gebruik een vereenvoudigde menustructuur zonder submenu&apos;s</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Gebruik platte menu&apos;s (geen submenu&apos;s)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Start op naar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Zet op &apos;0&apos; om onmiddellijk op te starten zonder het menu te laten zien, of op -1 om onbepaalde tijd te wachten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Menu timeout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Kernel parameters</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>seconden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Als deze optie is ingeschakeld, wordt elk item dat u selecteert in het grub startmenu opgeslagen als de nieuwe standaard voor toekomstige opstarts</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Inschakelen van laatste opstartkeuze opslaan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Achtergrond</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Afbeelding</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Thema inschakelen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Splash</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Voorbeeld</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Berichten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Zeer gedetailleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Gedetailleerd (standaard instelling)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Beperkt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Laat log zien</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Toon help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Hulp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Over deze toepassing</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Over...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Verlaat de applicatie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Toepassen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="112"/>
        <source>Still running</source>
        <translation>Loopt nog</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="437"/>
        <location filename="../src/mainwindow.cpp" line="445"/>
        <location filename="../src/mainwindow.cpp" line="479"/>
        <location filename="../src/mainwindow.cpp" line="590"/>
        <location filename="../src/mainwindow.cpp" line="1475"/>
        <location filename="../src/mainwindow.cpp" line="1488"/>
        <location filename="../src/mainwindow.cpp" line="1494"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="426"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Installeren opstart splash, wachten a.u.b.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <location filename="../src/mainwindow.cpp" line="1226"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="1229"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="433"/>
        <source>Updating sources</source>
        <translation>Bronnen opwaarderen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="445"/>
        <source>Could not install the bootsplash.</source>
        <translation>Kon opstart splash niet installeren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="590"/>
        <source>Could not create a temporary folder</source>
        <translation>Kon tijdelijke folder niet creëren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="599"/>
        <location filename="../src/mainwindow.cpp" line="619"/>
        <source>Cannot continue</source>
        <translation>Kan niet doorgaan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="599"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="620"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Kan geen chroot omgeving creëeren, kan geen opstart opties wijzigen. Stoppen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <location filename="../src/mainwindow.cpp" line="1391"/>
        <source>Updating configuration, please wait</source>
        <translation>Configuratie opwaarderen, wachten a.u.b.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1025"/>
        <source>Updating initramfs...</source>
        <translation>initramfs opwaarderen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1039"/>
        <location filename="../src/mainwindow.cpp" line="1406"/>
        <source>Updating grub...</source>
        <translation>Grub opwaarderen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1064"/>
        <source>About %1</source>
        <translation>Over %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1065"/>
        <source>Version: </source>
        <translation>Versie:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1067"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programma voor het selecteren van veel voorkomende opstart keuzes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1069"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1070"/>
        <source>%1 License</source>
        <translation>%1 Licentie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1091"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1101"/>
        <location filename="../src/mainwindow.cpp" line="1368"/>
        <source>Running in a Virtual Machine</source>
        <translation>Lopend in een Virtuele Machine</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1102"/>
        <location filename="../src/mainwindow.cpp" line="1369"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>Uw huidige systeem draait in een Virtuele Machine,
Plymouth opstart splash werkt in een beperkte mate, u zult ook niet in staat zijn om het thema van tevoor te bekijken</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1109"/>
        <source>Plymouth packages not installed</source>
        <translation>Plymouth pakketten niet geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1110"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Plymouth pakketten zijn momenteel niet geïnstalleerd.
OK om door te gaan en te installeren?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1136"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Afbeeldingen (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1301"/>
        <source>Could not read the systemd boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1302"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1303"/>
        <source> from %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1306"/>
        <source>Could not find any boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1307"/>
        <source>Could not find log at %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1309"/>
        <source>Log not found</source>
        <translation>Log niet gevonden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1350"/>
        <source>Preview Unavailable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1351"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1475"/>
        <source>Could not retrieve UUID for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1483"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Voer wachtwoord in om versleutelde partitie %1 te ontgrendelen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1488"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1494"/>
        <source>Could not open %1 LUKS container</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1321"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="113"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Live System Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="195"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Live System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Installed System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="437"/>
        <source>Failed to update package sources.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="441"/>
        <source>Installing packages:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="451"/>
        <source>Success</source>
        <translation>Gelukt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="451"/>
        <source>Bootsplash installed successfully.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="479"/>
        <source>Failed to create temporary file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1047"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1049"/>
        <source>Your changes have been successfully applied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1050"/>
        <source>Operation Complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1135"/>
        <source>Select image to display in bootloader</source>
        <translation>Select afbeelding om weer te geven in de opstartlader</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1314"/>
        <source>Boot Log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1357"/>
        <source>Needs reboot</source>
        <translation>Opnieuw opstarten vereist</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1358"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth was net geïnstalleerd, misschien moet u herstarten voordat u voorafbeeldingen kunt weergeven</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1431"/>
        <source>Click to select theme</source>
        <translation>Klik om thema te selecteren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1442"/>
        <source>Select GRUB theme</source>
        <translation>Selecteer GRUB thema</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programma voor het selecteren van veel voorkomende opstart keuzes</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="54"/>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="55"/>
        <location filename="../src/about.cpp" line="64"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="56"/>
        <source>Cancel</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="75"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>U lijkt ingelogd te zijn als root, gelieve uit te loggen en in te loggen als normale gebruiker om dit programma te gebruiken.</translation>
    </message>
</context>
</TS>