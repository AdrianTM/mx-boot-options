<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sk">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="204"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="205"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Bolo rozpoznané prostredie Live. Prosím zvoľte diskový oddiel root
systému, ktorý chcete upraviť (zobrazené sú iba Linuxové oddiely)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Nastavenia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Použit zjednodušené menu bez dielčích ponúk</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Použiť ploché menu (bez dielčích ponúk)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Zaviesť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Pre zavedenie systému bez zobrazenia menu zvoľte &apos;0&apos;, pre zobrazenie bez odpočtu &apos;-1&apos;</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Odpočet menu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>sekúnd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Pri tejto voľbe, čokoľvek vyberiete pri prvom zavedení bude nastavené ako predvolené pre ďalšie štarty systému </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Povoliť ukladanie poslednej voľby zavedenia systému</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Pozadie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Splash</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Náhľad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Zprávy</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Veľmi podrobne</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Detailne (predvolené nastavenie)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Obmedzené</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Zobraziť záznam</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Zobraziť nápovedu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Pomocník</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>O tejto aplikácii</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>O Programe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Zatvoriť aplikáciu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Zatvoriť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Použiť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="112"/>
        <source>Still running</source>
        <translation>Stále spustené</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="602"/>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <location filename="../src/mainwindow.cpp" line="645"/>
        <location filename="../src/mainwindow.cpp" line="769"/>
        <location filename="../src/mainwindow.cpp" line="1686"/>
        <location filename="../src/mainwindow.cpp" line="1699"/>
        <location filename="../src/mainwindow.cpp" line="1705"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="591"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Inštalácia bootsplash, prosím čakajte</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <location filename="../src/mainwindow.cpp" line="1426"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="1429"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Updating sources</source>
        <translation>Aktualizácia zdrojov</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="611"/>
        <source>Could not install the bootsplash.</source>
        <translation>Nepodarilo sa nainštalovať bootsplash.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="769"/>
        <source>Could not create a temporary folder</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="775"/>
        <location filename="../src/mainwindow.cpp" line="780"/>
        <location filename="../src/mainwindow.cpp" line="799"/>
        <source>Cannot continue</source>
        <translation>Nedá sa pokračovať</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="775"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="781"/>
        <location filename="../src/mainwindow.cpp" line="800"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Nejde vytvoriť chroot prostredie, žiadne zmeny v nastavení zavedenia. Ukončovanie...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1141"/>
        <location filename="../src/mainwindow.cpp" line="1600"/>
        <source>Updating configuration, please wait</source>
        <translation>Aktualizácia konfigurácie, prosím čakajte</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1225"/>
        <source>Updating initramfs...</source>
        <translation>Aktualizácia initramfs...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1246"/>
        <location filename="../src/mainwindow.cpp" line="1615"/>
        <source>Updating grub...</source>
        <translation>Aktualizácia GRUBu...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1273"/>
        <source>About %1</source>
        <translation>Okolo %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1274"/>
        <source>Version: </source>
        <translation>Verzia:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1276"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Program pre výber z volieb zavedenia systému</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1278"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1279"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1285"/>
        <source>%1 Help</source>
        <translation>%1 Pomoc</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1295"/>
        <location filename="../src/mainwindow.cpp" line="1570"/>
        <source>Running in a Virtual Machine</source>
        <translation>Spustené vo Virtuálnej Mašine</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1296"/>
        <location filename="../src/mainwindow.cpp" line="1571"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>Váš systém beží vo Virtuálnej Mašine,
Plymouth bootsplash bude fungovať v obmedzenej miere, taktiež nebude možné zobraziť náhľad</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1303"/>
        <source>Plymouth packages not installed</source>
        <translation>Plymouth nie je nainštalované</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1304"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Plymouth nie je nainštalované.
Prajete si ho nainštalovať?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1336"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Orázky (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1501"/>
        <source>Could not read the systemd boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1502"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1503"/>
        <source> from %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1506"/>
        <source>Could not find any boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1507"/>
        <source>Could not find log at %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1509"/>
        <source>Log not found</source>
        <translation>Záznam nebol nájdený</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1550"/>
        <source>Preview Unavailable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1551"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1686"/>
        <source>Could not retrieve UUID for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1694"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1699"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1705"/>
        <source>Could not open %1 LUKS container</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1521"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="113"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Live System Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="195"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Live System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Installed System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="602"/>
        <source>Failed to update package sources.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="607"/>
        <source>Installing packages:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="617"/>
        <source>Success</source>
        <translation>Úspech</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="617"/>
        <source>Bootsplash installed successfully.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="645"/>
        <source>Failed to create temporary file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1256"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1258"/>
        <source>Your changes have been successfully applied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1259"/>
        <source>Operation Complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1335"/>
        <source>Select image to display in bootloader</source>
        <translation>Vybrať obrázok pre bootloader</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1514"/>
        <source>Boot Log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1557"/>
        <source>Needs reboot</source>
        <translation>Je potrebný reštart PC</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1558"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth bolo nainštalované, pre zobrazenie náhľadov možno bude potrebné reštartovať PC</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1642"/>
        <source>Click to select theme</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1653"/>
        <source>Select GRUB theme</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Program pre výber z volieb zavedenia systému</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>História zmien</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Zrušiť</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Zatvoriť</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Chyba</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>