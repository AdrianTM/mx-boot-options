<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="274"/>
        <source>Administrator Access Required</source>
        <translation>Se requiere acceso de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="275"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operación requiere privilegios de administrador. Reinicia la aplicación e ingresa tu contraseña cuando se te solicite.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Ambiente en vivo detectado. Favor seleccione la partición raíz del sistema que desea modificar (solamente muestran particiones Linux)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>Está bien</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Usa estructura simplificada de menús sin submenús</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Utiliza menús planos (sin sub-menus)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>arrancar desde</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Fijar en &apos;0&apos; para iniciar inmediatamente sin mostrar el menú, ó a &apos;-1&apos; para esperar la selección</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Limite de tiempo del Menú</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Parámetros del kernel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>segundos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Con esta opción habilitada, cualquier entrada seleccionada del menú grub será guardada como predeterminada para futuros inicios</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Habilitar el guardado de la última selección de inicio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>Administrar las opciones de arranque de UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Enable background</source>
        <translation>Activar el fondo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Activar tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Pantalla de bienvenida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Mensajes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Muy detallada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Detallada (ajuste predeterminado)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Limitada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Desplegar registro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Terminar aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="226"/>
        <source>Still running</source>
        <translation>Aun ejecutando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1419"/>
        <location filename="../src/mainwindow.cpp" line="1431"/>
        <location filename="../src/mainwindow.cpp" line="1460"/>
        <location filename="../src/mainwindow.cpp" line="1469"/>
        <location filename="../src/mainwindow.cpp" line="1475"/>
        <location filename="../src/mainwindow.cpp" line="1486"/>
        <location filename="../src/mainwindow.cpp" line="1502"/>
        <location filename="../src/mainwindow.cpp" line="1507"/>
        <location filename="../src/mainwindow.cpp" line="1646"/>
        <location filename="../src/mainwindow.cpp" line="2777"/>
        <location filename="../src/mainwindow.cpp" line="2791"/>
        <location filename="../src/mainwindow.cpp" line="2797"/>
        <location filename="../src/mainwindow.cpp" line="2801"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1405"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Instalando pantalla de bienvenida, favor espere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="290"/>
        <location filename="../src/mainwindow.cpp" line="2472"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation>La vista previa está desactivada porque el parámetro &quot;splash&quot; no está presente en la línea de comandos del kernel. Para habilitar la vista previa, añada &quot;splash&quot; a los parámetros de arranque y reinicie.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="294"/>
        <location filename="../src/mainwindow.cpp" line="2475"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>La vista previa está deshabilitada mientras usa Wayland. Inicie una sesión X11 para la vista previa de los temas Plymouth.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="327"/>
        <source>The live boot menu&apos;s default entry is controlled by the MX boot scripts and cannot be changed here.</source>
        <translation>La opción predeterminada del menú de arranque en modo vivo está controlada por los scripts de arranque de MX y no se puede modificar aquí.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1403"/>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <location filename="../src/mainwindow.cpp" line="2653"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1412"/>
        <source>Updating sources</source>
        <translation>Actualizando recursos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1431"/>
        <source>Could not install the bootsplash.</source>
        <translation>No se pudo instalar la pantalla de bienvenida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1460"/>
        <source>Cannot find %1 to update.</source>
        <translation>No se encuentra %1 para actualizar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1470"/>
        <source>Failed to rotate backup %1; leaving the current configuration in place.</source>
        <translation>No se pudo cambiar la copia de seguridad %1; se mantiene la configuración actual.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1476"/>
        <source>Failed to remove old backup %1; leaving the current configuration in place.</source>
        <translation>No se pudo eliminar la copia de seguridad antigua %1; se mantiene la configuración actual.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Failed to back up %1; leaving the current configuration in place.</source>
        <translation>No se pudo realizar la copia de seguridad de %1; se mantiene la configuración actual.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1503"/>
        <source>Wrote %1, but could not confirm the change was saved durably. Please verify it before rebooting.</source>
        <translation>Se ha escrito %1, pero no se pudo confirmar que el cambio se haya guardado de forma permanente. Por favor, compruébelo antes de reiniciar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1508"/>
        <source>Failed to write %1; the previous configuration was left in place.</source>
        <translation>No se pudo escribir %1; se ha mantenido la configuración anterior.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1646"/>
        <source>Could not create a temporary folder</source>
        <translation>No se pudo crear una carpeta temporal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1652"/>
        <location filename="../src/mainwindow.cpp" line="1657"/>
        <location filename="../src/mainwindow.cpp" line="1680"/>
        <source>Cannot continue</source>
        <translation>No es posible continuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1652"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation>No se pudo abrir el dispositivo LUKS. Saliendo...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1658"/>
        <location filename="../src/mainwindow.cpp" line="1681"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>No es posible crear ambiente de chroot, imposible cambiar opciones de inicio. Saliendo...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2092"/>
        <location filename="../src/mainwindow.cpp" line="2655"/>
        <source>Updating configuration, please wait</source>
        <translation>Actualizando configuración, favor espere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2116"/>
        <source>saving the kernel boot arguments to the live media</source>
        <translation>guardando los parámetros de arranque del kernel en el soporte de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2119"/>
        <source>saving the kernel boot arguments to the syslinux configuration</source>
        <translation>guardando los parámetros de arranque del kernel en la configuración de Syslinux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2129"/>
        <source>saving the live boot menu timeout</source>
        <translation>guardando el tiempo de espera del menú de arranque en vivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2132"/>
        <source>saving the live boot menu background image</source>
        <translation>guardando la imagen de fondo del menú de arranque en vivo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2136"/>
        <source>clearing the pending one-time boot entry</source>
        <translation>borrando la entrada de arranque único pendiente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2167"/>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <source>setting the one-time boot entry</source>
        <translation>configurar la entrada de arranque único</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2180"/>
        <location filename="../src/mainwindow.cpp" line="2183"/>
        <source>saving the default boot entry</source>
        <translation>guardando la entrada de arranque predeterminada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2199"/>
        <location filename="../src/mainwindow.cpp" line="2203"/>
        <source>setting the boot splash theme</source>
        <translation>configurar el tema de la pantalla de inicio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2207"/>
        <location filename="../src/mainwindow.cpp" line="2210"/>
        <source>updating the boot log service state</source>
        <translation>actualizando el estado del servicio de registro de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2212"/>
        <source>Updating initramfs...</source>
        <translation>Actualizando initramfs...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2213"/>
        <source>updating the initramfs</source>
        <translation>Actualizado el initramfs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2225"/>
        <source>updating boot message settings</source>
        <translation>actualizando la configuración de los mensajes de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2238"/>
        <location filename="../src/mainwindow.cpp" line="2267"/>
        <source>saving the GRUB configuration file</source>
        <translation>guardando el archivo de configuración de GRUB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2239"/>
        <location filename="../src/mainwindow.cpp" line="2670"/>
        <source>Updating grub...</source>
        <translation>Actualizando grub...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2240"/>
        <source>regenerating the GRUB boot menu</source>
        <translation>regenerando el menú de arranque de GRUB</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2246"/>
        <source>copying the GRUB configuration to the boot media</source>
        <translation>copiando la configuración de GRUB al soporte de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2254"/>
        <source>Refreshing live boot labels...</source>
        <translation>Actualizando las etiquetas de arranque en tiempo real...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2255"/>
        <source>refreshing the live boot menu labels</source>
        <translation>actualizando las etiquetas del menú de arranque en tiempo real</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2275"/>
        <source>Operation Incomplete</source>
        <translation>Operación incompleta</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2276"/>
        <source>The following changes could not be applied: %1. These changes are still pending; please try applying again.</source>
        <translation>No se pudieron aplicar los siguientes cambios: %1. Estos cambios siguen pendientes; por favor, inténtelo de nuevo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2296"/>
        <source>Operation Cancelled</source>
        <translation>Operación cancelada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2297"/>
        <source>The operation was cancelled. Changes already completed were kept; the remaining changes are still pending.</source>
        <translation>La operación fue cancelada. Se conservaron los cambios ya realizados; el resto de cambios siguen pendientes.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2320"/>
        <source>Version: </source>
        <translation>Versión:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2322"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para escoger selecciones comunes de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2324"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2331"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2341"/>
        <location filename="../src/mainwindow.cpp" line="2616"/>
        <source>Running in a Virtual Machine</source>
        <translation>Ejecutando en una Máquina Virtual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2349"/>
        <source>Plymouth packages not installed</source>
        <translation>Paquetes de Plymouth no instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2350"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Los paquetes de Plymouth no están instalados actualmente
¿Está bien instalarlos? </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2382"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Imágenes (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2547"/>
        <source>Could not read the systemd boot logs.</source>
        <translation>No se pudieron leer los registros de arranque de systemd.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2548"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation>No se pudo leer los registros de arranque de systemd %1 ni el registro de reserva en %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2549"/>
        <source> from %1</source>
        <translation>desde %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2552"/>
        <source>Could not find any boot logs.</source>
        <translation>No se encontraron registros de arranque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2553"/>
        <source>Could not find log at %1</source>
        <translation>No se encontró el registro en %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2555"/>
        <source>Log not found</source>
        <translation>Registro no encontrado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2596"/>
        <source>Preview Unavailable</source>
        <translation>Vista previa no disponible</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2597"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>La vista previa no está disponible mientras usa Wayland. Inicie una sesión X11 para la vista previa de los temas Plymouth.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2731"/>
        <source>Click to select image</source>
        <translation>Haga clic para seleccionar la imagen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2777"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>No se pudo recuperar el UUID para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2785"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Ingrese la contraseña para desbloquear la partición cifrada %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2791"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation>Contraseña cancelada o vacía para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2797"/>
        <source>Could not open %1 LUKS container</source>
        <translation>No se pudo abrir el contenedor LUKS %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2801"/>
        <source>Could not mount %1 LUKS container</source>
        <translation>No se pudo montar el contenedor LUKS %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2567"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation>El proceso sigue en ejecución. ¿Seguro que quiere salir?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <source>Live System Detected</source>
        <translation>Sistema Live detectado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation>Actualmente está ejecutando un sistema Live. ¿Desea modificar las opciones de arranque para el sistema Live o para un sistema instalado?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="342"/>
        <source>Live System</source>
        <translation>Sistema Live</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Installed System</source>
        <translation>Sistema Instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1419"/>
        <source>Failed to update package sources.</source>
        <translation>Error al actualizar las fuentes de los paquetes.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1424"/>
        <source>Installing packages:</source>
        <translation>Instalando paquetes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1440"/>
        <source>Success</source>
        <translation>Éxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1440"/>
        <source>Bootsplash installed successfully.</source>
        <translation>Bootsplash instalado con éxito.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2282"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation>En este momento se está ejecutando en modo Live con la opción &quot;toram&quot;. Por favor, recuerda guardar el archivo de persistencia o remaster, de lo contrario cualquier cambio realizado se perderá.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2284"/>
        <source>Your changes have been successfully applied.</source>
        <translation>Los cambios se han aplicado con éxito.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2285"/>
        <source>Operation Complete</source>
        <translation>Operación completada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2342"/>
        <location filename="../src/mainwindow.cpp" line="2617"/>
        <source>Your current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>Su sistema actual se ejecuta en una máquina virtual,
la pantalla de arranque de Plymouth funcionará de forma limitada y tampoco podrá previsualizar el tema.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2381"/>
        <source>Select image to display in bootloader</source>
        <translation>Seleccionar imagen para mostrar en el cargador de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2560"/>
        <source>Boot Log</source>
        <translation>Registro de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2603"/>
        <source>Needs reboot</source>
        <translation>Necesita reinciar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2604"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Acaba de instalar Plymouth; puede ser necesario reiniciar para mostrar las previsualizaciones </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2712"/>
        <source>Click to select theme</source>
        <translation>Haga clic para seleccionar el tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2744"/>
        <source>Select GRUB theme</source>
        <translation>Seleccionar tema del GRUB</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para escoger selecciones comunes de arranque</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>No se pudo cargar el registro de cambios.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para utilizar este programa.</translation>
    </message>
</context>
</TS>