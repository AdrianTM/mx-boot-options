<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="it">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="274"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="275"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Rilevato ambiente live. Selezionare la partizione di root del sistema
che si desidera modificare (vengono visualizzate solo le partizioni Linux)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opzioni</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Usare una struttura di menu semplificata senza sottomenu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Usa menu lineari (senza submenu)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Avvio su</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Impostare su &apos;0&apos; per avviare immediatamente senza visualizzare il menu, o su &apos;-1&apos; per mettere in attesa indefinitamente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Programma per selezionare le scelte di avvio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Parametri del Kernel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>secondi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Con questa opzione abilitata, qualsiasi voce selezionata dal menu di avvio di grub verrà salvata come nuova impostazione predefinita per gli avvii futuri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Abilita il salvataggio dell&apos;ultima scelta di avvio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>Gestisce opzioni di avvio UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Sfondo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Enable background</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Abilita tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Splash</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Anteprima</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Messaggi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Molto dettagliato</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Dettagliato (impostazione predefinita) </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Limitato</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Visualizza log</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Visualizza la guida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Informazioni su questa applicazione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Info...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Esci dall&apos;applicazione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="226"/>
        <source>Still running</source>
        <translation>in esecuzione</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1419"/>
        <location filename="../src/mainwindow.cpp" line="1431"/>
        <location filename="../src/mainwindow.cpp" line="1460"/>
        <location filename="../src/mainwindow.cpp" line="1469"/>
        <location filename="../src/mainwindow.cpp" line="1475"/>
        <location filename="../src/mainwindow.cpp" line="1486"/>
        <location filename="../src/mainwindow.cpp" line="1502"/>
        <location filename="../src/mainwindow.cpp" line="1507"/>
        <location filename="../src/mainwindow.cpp" line="1646"/>
        <location filename="../src/mainwindow.cpp" line="2777"/>
        <location filename="../src/mainwindow.cpp" line="2791"/>
        <location filename="../src/mainwindow.cpp" line="2797"/>
        <location filename="../src/mainwindow.cpp" line="2801"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1405"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Installazione del boot-splash, attendere...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="290"/>
        <location filename="../src/mainwindow.cpp" line="2472"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="294"/>
        <location filename="../src/mainwindow.cpp" line="2475"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="327"/>
        <source>The live boot menu&apos;s default entry is controlled by the MX boot scripts and cannot be changed here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1403"/>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <location filename="../src/mainwindow.cpp" line="2653"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1412"/>
        <source>Updating sources</source>
        <translation>Aggiornamento delle fonti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1431"/>
        <source>Could not install the bootsplash.</source>
        <translation>Non si riesce ad installare il bootsplash.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1460"/>
        <source>Cannot find %1 to update.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1470"/>
        <source>Failed to rotate backup %1; leaving the current configuration in place.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1476"/>
        <source>Failed to remove old backup %1; leaving the current configuration in place.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Failed to back up %1; leaving the current configuration in place.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1503"/>
        <source>Wrote %1, but could not confirm the change was saved durably. Please verify it before rebooting.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1508"/>
        <source>Failed to write %1; the previous configuration was left in place.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1646"/>
        <source>Could not create a temporary folder</source>
        <translation>Impossibile creare una cartella temporanea</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1652"/>
        <location filename="../src/mainwindow.cpp" line="1657"/>
        <location filename="../src/mainwindow.cpp" line="1680"/>
        <source>Cannot continue</source>
        <translation>Non è possibile continuare</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1652"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1658"/>
        <location filename="../src/mainwindow.cpp" line="1681"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Impossibile creare l&apos;ambiente chroot, non è possibile modificare le opzioni di avvio. Chiusura in corso ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2092"/>
        <location filename="../src/mainwindow.cpp" line="2655"/>
        <source>Updating configuration, please wait</source>
        <translation>Aggiornamento della configurazione, attendere...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2116"/>
        <source>saving the kernel boot arguments to the live media</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2119"/>
        <source>saving the kernel boot arguments to the syslinux configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2129"/>
        <source>saving the live boot menu timeout</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2132"/>
        <source>saving the live boot menu background image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2136"/>
        <source>clearing the pending one-time boot entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2167"/>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <source>setting the one-time boot entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2180"/>
        <location filename="../src/mainwindow.cpp" line="2183"/>
        <source>saving the default boot entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2199"/>
        <location filename="../src/mainwindow.cpp" line="2203"/>
        <source>setting the boot splash theme</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2207"/>
        <location filename="../src/mainwindow.cpp" line="2210"/>
        <source>updating the boot log service state</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2212"/>
        <source>Updating initramfs...</source>
        <translation> Aggiornamento di initramfs... </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2213"/>
        <source>updating the initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2225"/>
        <source>updating boot message settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2238"/>
        <location filename="../src/mainwindow.cpp" line="2267"/>
        <source>saving the GRUB configuration file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2239"/>
        <location filename="../src/mainwindow.cpp" line="2670"/>
        <source>Updating grub...</source>
        <translation>Aggiornamento di grub...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2240"/>
        <source>regenerating the GRUB boot menu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2246"/>
        <source>copying the GRUB configuration to the boot media</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2254"/>
        <source>Refreshing live boot labels...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2255"/>
        <source>refreshing the live boot menu labels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2275"/>
        <source>Operation Incomplete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2276"/>
        <source>The following changes could not be applied: %1. These changes are still pending; please try applying again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2296"/>
        <source>Operation Cancelled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2297"/>
        <source>The operation was cancelled. Changes already completed were kept; the remaining changes are still pending.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <source>About %1</source>
        <translation>Circa %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2320"/>
        <source>Version: </source>
        <translation>Versione: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2322"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programma per selezionare le scelte di avvio</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2324"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>%1 License</source>
        <translation>%1 Licenza</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2331"/>
        <source>%1 Help</source>
        <translation>%1 Aiuto</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2341"/>
        <location filename="../src/mainwindow.cpp" line="2616"/>
        <source>Running in a Virtual Machine</source>
        <translation>Esecuzione in una Macchina Virtuale</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2349"/>
        <source>Plymouth packages not installed</source>
        <translation>I pacchetti di Plymouth non sono installati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2350"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>I pacchetti di Plymouth attualmente non sono installati.
OK per andare avanti ed installarli?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2382"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Immagini (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2547"/>
        <source>Could not read the systemd boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2548"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2549"/>
        <source> from %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2552"/>
        <source>Could not find any boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2553"/>
        <source>Could not find log at %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2555"/>
        <source>Log not found</source>
        <translation>File log non trovato</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2596"/>
        <source>Preview Unavailable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2597"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2731"/>
        <source>Click to select image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2777"/>
        <source>Could not retrieve UUID for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2785"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Digita la password per sbloccare la partizione criptata:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2791"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2797"/>
        <source>Could not open %1 LUKS container</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2801"/>
        <source>Could not mount %1 LUKS container</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2567"/>
        <source>&amp;Close</source>
        <translation>C&amp;hiudi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <source>Live System Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="342"/>
        <source>Live System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Installed System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1419"/>
        <source>Failed to update package sources.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1424"/>
        <source>Installing packages:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1440"/>
        <source>Success</source>
        <translation>Operazione riuscita</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1440"/>
        <source>Bootsplash installed successfully.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2282"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2284"/>
        <source>Your changes have been successfully applied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2285"/>
        <source>Operation Complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2342"/>
        <location filename="../src/mainwindow.cpp" line="2617"/>
        <source>Your current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2381"/>
        <source>Select image to display in bootloader</source>
        <translation>Seleziona un&apos;immagine da visualizzare nel bootloader</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2560"/>
        <source>Boot Log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2603"/>
        <source>Needs reboot</source>
        <translation>E&apos; necessario fare il re-boot</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2604"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth è stato appena installato, potrebbe essere necessario riavviare il sistema prima di poter visualizzare le anteprime</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2712"/>
        <source>Click to select theme</source>
        <translation>Clicca per selezionare il tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2744"/>
        <source>Select GRUB theme</source>
        <translation>Seleziona il tema di GRUB</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programma per selezionare le scelte di avvio</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Registro delle modifiche</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sembra che tu sia loggato come root, fai il log out e poi il log in come utente normale per usare questo programma.</translation>
    </message>
</context>
</TS>