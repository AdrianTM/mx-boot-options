<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="274"/>
        <source>Administrator Access Required</source>
        <translation>Zahtevan je skrbniški dostop</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="275"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Za ta operacijo je potreben skrbniški dostop. Ponovno zaženite program in vnesite geslo, ko ga bo program zahteval.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Zaznano je bilo živo okolje. Prosimo, izberite korenski razdelek
sistema, ki ga želite spreminjati (prikazani so le Linux razdelki)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opcije</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Uporabi preprostejšo strukturo menija brez podmenijev</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Uporabi ploske menije (brez podmenijev)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Zagon v</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Nastavi na &apos;0&apos; za takojšen zagon brez prikaza menija ali &apos;-1&apos; za nedoločen čas čakanja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Čas prikaza menija</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Parametri jedra</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>sekund</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Če je izbrana ta opcija, bo vsak vnos, ki ga izberete v zagonskem meniju Grub, shranjen kot nova privzeta vrednost za prihodnje zagone</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Vklopi shranjevanje izborov zadnjega zagona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>Upravljanje možnosti UEFI zagona</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Ozadje</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Enable background</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Vklopi temo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Pozdrav</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Predogled</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Sporočila</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Zelo podrobno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Podrobno (privzeto)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Omejeno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Prikaži dnevnik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Prikaži pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>O tem programu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Zapri aplikacijo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Uveljavi</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="226"/>
        <source>Still running</source>
        <translation>Se še vedno izvaja</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1419"/>
        <location filename="../src/mainwindow.cpp" line="1431"/>
        <location filename="../src/mainwindow.cpp" line="1460"/>
        <location filename="../src/mainwindow.cpp" line="1469"/>
        <location filename="../src/mainwindow.cpp" line="1475"/>
        <location filename="../src/mainwindow.cpp" line="1486"/>
        <location filename="../src/mainwindow.cpp" line="1502"/>
        <location filename="../src/mainwindow.cpp" line="1507"/>
        <location filename="../src/mainwindow.cpp" line="1646"/>
        <location filename="../src/mainwindow.cpp" line="2777"/>
        <location filename="../src/mainwindow.cpp" line="2791"/>
        <location filename="../src/mainwindow.cpp" line="2797"/>
        <location filename="../src/mainwindow.cpp" line="2801"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1405"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Namesčanje zagonske predstavitve, prosim počakajte...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="290"/>
        <location filename="../src/mainwindow.cpp" line="2472"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation>Predogled je izklopljen, ker ni podan parameter &apos;splash&apos; v ukazni vrstici jedra. Dodajte &apos;splash&apos; v zagonske parametre, če želite omogočiti predogled in opravite ponovni zagon.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="294"/>
        <location filename="../src/mainwindow.cpp" line="2475"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>Predogled je onemogočen, ko je zagnan pod Wayland. Za predogled Plymouth tem zaženite X11 sejo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="327"/>
        <source>The live boot menu&apos;s default entry is controlled by the MX boot scripts and cannot be changed here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1403"/>
        <location filename="../src/mainwindow.cpp" line="2090"/>
        <location filename="../src/mainwindow.cpp" line="2653"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1412"/>
        <source>Updating sources</source>
        <translation>Posodobi vire</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1431"/>
        <source>Could not install the bootsplash.</source>
        <translation>Neuspešno nameščanje zagonske predstavitve</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1460"/>
        <source>Cannot find %1 to update.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1470"/>
        <source>Failed to rotate backup %1; leaving the current configuration in place.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1476"/>
        <source>Failed to remove old backup %1; leaving the current configuration in place.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1487"/>
        <source>Failed to back up %1; leaving the current configuration in place.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1503"/>
        <source>Wrote %1, but could not confirm the change was saved durably. Please verify it before rebooting.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1508"/>
        <source>Failed to write %1; the previous configuration was left in place.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1646"/>
        <source>Could not create a temporary folder</source>
        <translation>Začasne mape ni bilo mogoče ustvariti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1652"/>
        <location filename="../src/mainwindow.cpp" line="1657"/>
        <location filename="../src/mainwindow.cpp" line="1680"/>
        <source>Cannot continue</source>
        <translation>Ne morem nadaljevati</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1652"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation>LUKS naprave ni mogoče odpreti. Izhod...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1658"/>
        <location filename="../src/mainwindow.cpp" line="1681"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Ne morem ustvaiti chroot okolja, ne morem spremeniti opciji zagona. Končujem...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2092"/>
        <location filename="../src/mainwindow.cpp" line="2655"/>
        <source>Updating configuration, please wait</source>
        <translation>Posodabljanje konfiguracije, prosimo počakajte</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2116"/>
        <source>saving the kernel boot arguments to the live media</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2119"/>
        <source>saving the kernel boot arguments to the syslinux configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2129"/>
        <source>saving the live boot menu timeout</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2132"/>
        <source>saving the live boot menu background image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2136"/>
        <source>clearing the pending one-time boot entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2167"/>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <source>setting the one-time boot entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2180"/>
        <location filename="../src/mainwindow.cpp" line="2183"/>
        <source>saving the default boot entry</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2199"/>
        <location filename="../src/mainwindow.cpp" line="2203"/>
        <source>setting the boot splash theme</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2207"/>
        <location filename="../src/mainwindow.cpp" line="2210"/>
        <source>updating the boot log service state</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2212"/>
        <source>Updating initramfs...</source>
        <translation>Posodabljam initramfs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2213"/>
        <source>updating the initramfs</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2225"/>
        <source>updating boot message settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2238"/>
        <location filename="../src/mainwindow.cpp" line="2267"/>
        <source>saving the GRUB configuration file</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2239"/>
        <location filename="../src/mainwindow.cpp" line="2670"/>
        <source>Updating grub...</source>
        <translation>Posodabljam grub...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2240"/>
        <source>regenerating the GRUB boot menu</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2246"/>
        <source>copying the GRUB configuration to the boot media</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2254"/>
        <source>Refreshing live boot labels...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2255"/>
        <source>refreshing the live boot menu labels</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2275"/>
        <source>Operation Incomplete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2276"/>
        <source>The following changes could not be applied: %1. These changes are still pending; please try applying again.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2296"/>
        <source>Operation Cancelled</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2297"/>
        <source>The operation was cancelled. Changes already completed were kept; the remaining changes are still pending.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <source>About %1</source>
        <translation>O %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2320"/>
        <source>Version: </source>
        <translation>Različica:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2322"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Program za določitev izbora pri običajnem zagonu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2324"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Avtorska zaščita (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>%1 License</source>
        <translation>%1 licenca</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2331"/>
        <source>%1 Help</source>
        <translation>%1 pomoč</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2341"/>
        <location filename="../src/mainwindow.cpp" line="2616"/>
        <source>Running in a Virtual Machine</source>
        <translation>Izvajanje v navideznem sistemu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2349"/>
        <source>Plymouth packages not installed</source>
        <translation>Plymouth paketi niso nameščeni</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2350"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Plymouth paketi trenutno niso nameščeni.
Naj nadaljujem in jih namestim?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2382"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Slike (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2547"/>
        <source>Could not read the systemd boot logs.</source>
        <translation>Ne morem prebrati zagonskih systemd dnevnikov.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2548"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation>Ne morem prebrati zagonskih systemd dnevnikov %1 ali povratnih dnevnikov na %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2549"/>
        <source> from %1</source>
        <translation>iz %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2552"/>
        <source>Could not find any boot logs.</source>
        <translation>Ne morem najti katerekoli zagonske dnevnike.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2553"/>
        <source>Could not find log at %1</source>
        <translation>Nisem našel dnevnika na %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2555"/>
        <source>Log not found</source>
        <translation>Dnevnik ni bil najden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2596"/>
        <source>Preview Unavailable</source>
        <translation>Predogled ni na voljo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2597"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>Predogled je onemogočen, ko je zagnan pod Wayland. Za predogled Plymouth tem zaženite X11 sejo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2731"/>
        <source>Click to select image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2777"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Za %1 ni mogoče pridobiti UUID</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2785"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Vnesite geslo za odklep šifriranega razdelka %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2791"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation>Vnos gesla za %1 je bil prekinjen ali prazen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2797"/>
        <source>Could not open %1 LUKS container</source>
        <translation>LUKS zabojnika %1 ni bilo mogočer odpreti</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2801"/>
        <source>Could not mount %1 LUKS container</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2567"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="227"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation>Vsaj en proces se še vedno izvaja. Želite res končati?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="338"/>
        <source>Live System Detected</source>
        <translation>Zazna je živi sistem</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="340"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation>Trenutno se izvaja živi sistem. Bi radi prilagodili možnosti zagona za živi sistem ali za nameščeni sistem?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="342"/>
        <source>Live System</source>
        <translation>Živi sistem</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="343"/>
        <source>Installed System</source>
        <translation>Nameščeni sistem</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1419"/>
        <source>Failed to update package sources.</source>
        <translation>Paketnih virov ni bilo mogoče posodobiti.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1424"/>
        <source>Installing packages:</source>
        <translation>Nameščanje paketov:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1440"/>
        <source>Success</source>
        <translation>Uspešno</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1440"/>
        <source>Bootsplash installed successfully.</source>
        <translation>Bootsplash je bil uspešno nameščen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2282"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation>Trenutno se izvaja živi način z možnostjo &apos;toram&apos;. Shranite persistenčno datoteko ali remasterizacijo, sicer se bodo spremembe izgubile.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2284"/>
        <source>Your changes have been successfully applied.</source>
        <translation>Spremembe so bile uspešno izvedene.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2285"/>
        <source>Operation Complete</source>
        <translation>Opravilo je končano</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2342"/>
        <location filename="../src/mainwindow.cpp" line="2617"/>
        <source>Your current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2381"/>
        <source>Select image to display in bootloader</source>
        <translation>Izberite sliko, ki naj se prikaže v zagonskem nalagalniku</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2560"/>
        <source>Boot Log</source>
        <translation>Zagonski dnevnik</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2603"/>
        <source>Needs reboot</source>
        <translation>Potreben je ponovni zagon</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2604"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth je bil ravnokar nameščen, zato je morda potreben ponovni zagon, da bi lahko prikazal predoglede.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2712"/>
        <source>Click to select theme</source>
        <translation>Kliknite za izbiro teme</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2744"/>
        <source>Select GRUB theme</source>
        <translation>Izberite temo za GRUB</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Program za določitev občajnih izbir ob zagonu</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licenca</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Dnevnik sprememb</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Prekliči</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Zapri</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Prijevljeni ste kot korenski uporabnik. Izpišite se in se ponovno prijavite kot običajen uporabnik, če želite uporabljati ta program.</translation>
    </message>
</context>
</TS>