<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="nl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="204"/>
        <source>Administrator Access Required</source>
        <translation>Beheerdersrechten Vereist</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="205"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Voor deze bewerking zijn beheerdersrechten vereist. Start de toepassing opnieuw op en voer uw wachtwoord in wanneer daarom wordt gevraagd.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Live omgeving gedetecteerd. Selecteer aub de root partitie van het
systeem dat u wilt wijzigen (alleen Linux partities worden weergegeven)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Ongedaan maken</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opties</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Gebruik een vereenvoudigde menustructuur zonder submenu&apos;s</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Gebruik platte menu&apos;s (geen submenu&apos;s)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Start op naar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Zet op &apos;0&apos; om onmiddellijk op te starten zonder het menu te laten zien, of op -1 om onbepaalde tijd te wachten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Menu timeout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Kernel parameters</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>seconden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Als deze optie is ingeschakeld, wordt elk item dat u selecteert in het grub startmenu opgeslagen als de nieuwe standaard voor toekomstige opstarts</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Inschakelen van laatste opstartkeuze opslaan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Achtergrond</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Afbeelding</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Thema inschakelen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Splash</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Voorbeeld</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Berichten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Zeer gedetailleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Gedetailleerd (standaard instelling)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Beperkt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Laat log zien</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Toon help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Hulp</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Over deze toepassing</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Over...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Verlaat de applicatie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Sluiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Toepassen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="112"/>
        <source>Still running</source>
        <translation>Loopt nog</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <location filename="../src/mainwindow.cpp" line="618"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <location filename="../src/mainwindow.cpp" line="1711"/>
        <location filename="../src/mainwindow.cpp" line="1717"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Installeren opstart splash, wachten a.u.b.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <location filename="../src/mainwindow.cpp" line="1438"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="1441"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="605"/>
        <source>Updating sources</source>
        <translation>Bronnen opwaarderen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="618"/>
        <source>Could not install the bootsplash.</source>
        <translation>Kon opstart splash niet installeren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <source>Could not create a temporary folder</source>
        <translation>Kon tijdelijke folder niet creëren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <location filename="../src/mainwindow.cpp" line="806"/>
        <source>Cannot continue</source>
        <translation>Kan niet doorgaan</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <location filename="../src/mainwindow.cpp" line="807"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Kan geen chroot omgeving creëeren, kan geen opstart opties wijzigen. Stoppen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1149"/>
        <location filename="../src/mainwindow.cpp" line="1612"/>
        <source>Updating configuration, please wait</source>
        <translation>Configuratie opwaarderen, wachten a.u.b.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1233"/>
        <source>Updating initramfs...</source>
        <translation>initramfs opwaarderen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1254"/>
        <location filename="../src/mainwindow.cpp" line="1627"/>
        <source>Updating grub...</source>
        <translation>Grub opwaarderen...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1285"/>
        <source>About %1</source>
        <translation>Over %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1286"/>
        <source>Version: </source>
        <translation>Versie:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1288"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programma voor het selecteren van veel voorkomende opstart keuzes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1290"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1291"/>
        <source>%1 License</source>
        <translation>%1 Licentie</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1297"/>
        <source>%1 Help</source>
        <translation>%1 Help</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1307"/>
        <location filename="../src/mainwindow.cpp" line="1582"/>
        <source>Running in a Virtual Machine</source>
        <translation>Lopend in een Virtuele Machine</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1308"/>
        <location filename="../src/mainwindow.cpp" line="1583"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>Uw huidige systeem draait in een Virtuele Machine,
Plymouth opstart splash werkt in een beperkte mate, u zult ook niet in staat zijn om het thema van tevoor te bekijken</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1315"/>
        <source>Plymouth packages not installed</source>
        <translation>Plymouth pakketten niet geïnstalleerd</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1316"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Plymouth pakketten zijn momenteel niet geïnstalleerd.
OK om door te gaan en te installeren?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Afbeeldingen (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1513"/>
        <source>Could not read the systemd boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1514"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1515"/>
        <source> from %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1518"/>
        <source>Could not find any boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1519"/>
        <source>Could not find log at %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1521"/>
        <source>Log not found</source>
        <translation>Log niet gevonden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1562"/>
        <source>Preview Unavailable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1563"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <source>Could not retrieve UUID for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Voer wachtwoord in om versleutelde partitie %1 te ontgrendelen:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1711"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1717"/>
        <source>Could not open %1 LUKS container</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1533"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="113"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Live System Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="195"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Live System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Installed System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>Failed to update package sources.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>Installing packages:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Success</source>
        <translation>Gelukt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Bootsplash installed successfully.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Failed to create temporary file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1268"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1270"/>
        <source>Your changes have been successfully applied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1271"/>
        <source>Operation Complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1347"/>
        <source>Select image to display in bootloader</source>
        <translation>Select afbeelding om weer te geven in de opstartlader</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1526"/>
        <source>Boot Log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1569"/>
        <source>Needs reboot</source>
        <translation>Opnieuw opstarten vereist</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1570"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth was net geïnstalleerd, misschien moet u herstarten voordat u voorafbeeldingen kunt weergeven</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1654"/>
        <source>Click to select theme</source>
        <translation>Klik om thema te selecteren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1665"/>
        <source>Select GRUB theme</source>
        <translation>Selecteer GRUB thema</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programma voor het selecteren van veel voorkomende opstart keuzes</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licentie</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Changelog</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Ongedaan maken</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Sluiten</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Fout</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>U lijkt ingelogd te zijn als root, gelieve uit te loggen en in te loggen als normale gebruiker om dit programma te gebruiken.</translation>
    </message>
</context>
</TS>