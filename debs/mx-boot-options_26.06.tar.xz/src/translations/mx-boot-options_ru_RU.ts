<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru_RU">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="204"/>
        <source>Administrator Access Required</source>
        <translation>Требуется доступ администратора</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="205"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Эта операция требует прав администратора. Пожалуйста, перезапустите приложение и введите пароль при появлении соответствующего запроса.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Распознан сеанс Live-системы. Пожалуйста, выберите корневой раздел
системы, которую вы хотите изменить (отображены только разделы Linux)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>ОК</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Варианты</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Использовать упрощённое меню, без подменю</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Использовать плоское меню (без подменю)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Загрузить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Установите значение &apos;0&apos;, чтобы загрузиться немедленно без отображения меню, или &apos;-1&apos;, чтобы ждать бесконечно.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Таймаут меню</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Параметры ядра</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>секунд</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Если этот параметр включен, то любой выбранный вами пункт меню загрузки grub будет сохранен в качестве нового значения по умолчанию для будущих загрузок.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Включить сохранение последнего варианта загрузки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>Управление параметрами загрузки UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Фон</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Образ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Включить тему</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Splash</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Предварительный просмотр</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Сообщения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Очень подробно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Подробно (настройка по умолчанию)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Кратко</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Просмотр журнала</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Показать справку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Об этом приложении</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>О программе...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Выйти из приложения</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="112"/>
        <source>Still running</source>
        <translation>Все еще работает</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <location filename="../src/mainwindow.cpp" line="618"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <location filename="../src/mainwindow.cpp" line="1711"/>
        <location filename="../src/mainwindow.cpp" line="1717"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Установка bootsplash, подождите</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <location filename="../src/mainwindow.cpp" line="1438"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation>Предварительный просмотр отключен, поскольку параметр &apos;splash&apos; отсутствует в командной строке ядра. Чтобы включить предварительный просмотр, добавьте &apos;splash&apos; в параметры загрузки и перезагрузите систему.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="1441"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>Предварительный просмотр отключен при работе под Wayland. Для предварительного просмотра тем Plymouth запустите сеанс X11.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="605"/>
        <source>Updating sources</source>
        <translation>Обновление источников</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="618"/>
        <source>Could not install the bootsplash.</source>
        <translation>Не удалось установить bootsplash</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <source>Could not create a temporary folder</source>
        <translation>Не удалось создать временную папку</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <location filename="../src/mainwindow.cpp" line="806"/>
        <source>Cannot continue</source>
        <translation>Невозможно продолжить</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation>Невозможно открыть устройство LUKS. Выход...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <location filename="../src/mainwindow.cpp" line="807"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Невозможно создать среду chroot, изменить параметры загрузки. Выход ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1149"/>
        <location filename="../src/mainwindow.cpp" line="1612"/>
        <source>Updating configuration, please wait</source>
        <translation>Обновление конфигурации, пожалуйста, подождите</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1233"/>
        <source>Updating initramfs...</source>
        <translation>Обновление initramfs...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1254"/>
        <location filename="../src/mainwindow.cpp" line="1627"/>
        <source>Updating grub...</source>
        <translation>Обновление grub...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1285"/>
        <source>About %1</source>
        <translation>О %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1286"/>
        <source>Version: </source>
        <translation>Версия: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1288"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Программа для выбора общих вариантов запуска</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1290"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1291"/>
        <source>%1 License</source>
        <translation>%1 Лицензия</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1297"/>
        <source>%1 Help</source>
        <translation>%1 Справка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1307"/>
        <location filename="../src/mainwindow.cpp" line="1582"/>
        <source>Running in a Virtual Machine</source>
        <translation>Запуск в виртуальной машине</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1308"/>
        <location filename="../src/mainwindow.cpp" line="1583"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>Текущая система работает на виртуальной машине,
Plymouth bootsplash будет работать ограниченным образом, вы также не сможете просмотреть тему</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1315"/>
        <source>Plymouth packages not installed</source>
        <translation>Plymouth пакет не установлен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1316"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Пакеты Plymouth в настоящее время не установлены.
ОК, чтобы продолжить и установить их?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Изображения (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1513"/>
        <source>Could not read the systemd boot logs.</source>
        <translation>Не удалось прочитать журналы загрузки systemd.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1514"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation>Не удалось прочитать журналы загрузки systemd %1 или резервный журнал %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1515"/>
        <source> from %1</source>
        <translation>от %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1518"/>
        <source>Could not find any boot logs.</source>
        <translation>Не удалось найти журналы загрузки.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1519"/>
        <source>Could not find log at %1</source>
        <translation>Не удалось найти журнал в %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1521"/>
        <source>Log not found</source>
        <translation>Журнал не найден</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1562"/>
        <source>Preview Unavailable</source>
        <translation>Предварительный просмотр недоступен</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1563"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>Предварительный просмотр недоступен при использовании Wayland. Для предварительного просмотра тем Plymouth запустите сеанс X11.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Не удалось получить UUID для %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Введите пароль для открытия зашифрованного раздела %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1711"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation>Не введен пароль для %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1717"/>
        <source>Could not open %1 LUKS container</source>
        <translation>Не удалось открыть %1 контейнер LUKS</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1533"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="113"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation>Процесс все еще выполняется. Вы действительно хотите выйти?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Live System Detected</source>
        <translation>Обнаружена действующая система</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="195"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation>В данный момент вы используете живую систему. Хотите изменить параметры загрузки для живой системы или для установленной системы?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Live System</source>
        <translation>Живая система</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Installed System</source>
        <translation>Установленная система</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>Failed to update package sources.</source>
        <translation>Не удалось обновить источники пакетов.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>Installing packages:</source>
        <translation>Установка пакетов:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Bootsplash installed successfully.</source>
        <translation>Bootsplash успешно установлен.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Failed to create temporary file.</source>
        <translation>Не удалось создать временный файл.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1268"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation>В настоящее время вы работаете в режиме реального времени с опцией &apos;toram&apos;. Не забудьте сохранить файл персистентности или ремастер, иначе все внесенные изменения будут потеряны.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1270"/>
        <source>Your changes have been successfully applied.</source>
        <translation>Ваши изменения были успешно применены.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1271"/>
        <source>Operation Complete</source>
        <translation>Операция завершена</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1347"/>
        <source>Select image to display in bootloader</source>
        <translation>Выберите изображение для отображения в загрузчике</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1526"/>
        <source>Boot Log</source>
        <translation>Журнал загрузки</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1569"/>
        <source>Needs reboot</source>
        <translation>Требуется перезагрузка</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1570"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth только что был установлен, вам может потребоваться перезагрузка, прежде чем вы сможете отображать превью</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1654"/>
        <source>Click to select theme</source>
        <translation>Нажмите, чтобы выбрать тему</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1665"/>
        <source>Select GRUB theme</source>
        <translation>Выберите тему GRUB</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Программа для выбора общих вариантов запуска</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Не удалось загрузить %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Список изменений</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Не удалось загрузить список изменений.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Программа запущена суперпользователем. Для использования программы войдите в систему как обычный пользователь.</translation>
    </message>
</context>
</TS>