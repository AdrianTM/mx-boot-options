<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es_ES">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="204"/>
        <source>Administrator Access Required</source>
        <translation>Se requiere acceso de administrador</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="205"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operación requiere privilegios de administrador. Reinicia la aplicación e ingresa tu contraseña cuando se te solicite.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Entorno en vivo detectado. Seleccione la partición raíz del sistema 
que desea modificar (solo se muestran las particiones de Linux)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Use una estructura de menú simplificada sin submenús</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Use menús planos (sin submenus)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>arrancar desde</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Configure en &apos;0&apos; para arrancar inmediatamente sin mostrar el menú, o en &apos;-1&apos; para esperar indefinidamente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Tiempo de espera del menú</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Parámetros del kernel</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>segundos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Con esta opción habilitada, cualquier entrada seleccionada del menú grub será guardada como predeterminada para futuros arranques</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Habilitar guardar la última opción de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>Gestiona las opciones del arranque UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Fondo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Imagen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Activar tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Pantalla de bienvenida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Vista previa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Mensajes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Muy detallado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Detallado (configuracion por defecto)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Limitada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Mostrar registro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Mostrar la ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Acerca de esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Acerca de...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Salir de la aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="112"/>
        <source>Still running</source>
        <translation>ejecutandose</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <location filename="../src/mainwindow.cpp" line="618"/>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <location filename="../src/mainwindow.cpp" line="1711"/>
        <location filename="../src/mainwindow.cpp" line="1717"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="598"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Instalando pantalla de bienvenida, por favor espere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="169"/>
        <location filename="../src/mainwindow.cpp" line="1438"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation>La vista previa está desactivada porque el parámetro &quot;splash&quot; no está presente en la línea de comandos del kernel. Para habilitar la vista previa, añada &quot;splash&quot; a los parámetros de arranque y reinicie.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="173"/>
        <location filename="../src/mainwindow.cpp" line="1441"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>La vista previa está deshabilitada mientras usa Wayland. Inicie una sesión X11 para la vista previa de los temas Plymouth.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="605"/>
        <source>Updating sources</source>
        <translation>Actualizando recursos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="618"/>
        <source>Could not install the bootsplash.</source>
        <translation>No se pudo instalar la pantalla de bienvenida</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="776"/>
        <source>Could not create a temporary folder</source>
        <translation>No se pudo crear una carpeta temporal</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <location filename="../src/mainwindow.cpp" line="787"/>
        <location filename="../src/mainwindow.cpp" line="806"/>
        <source>Cannot continue</source>
        <translation>No es posible continuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="782"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation>No se pudo abrir el dispositivo LUKS. Saliendo...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="788"/>
        <location filename="../src/mainwindow.cpp" line="807"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>No se puede crear un entorno chroot, no se pueden cambiar las opciones de arranque. Saliendo ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1149"/>
        <location filename="../src/mainwindow.cpp" line="1612"/>
        <source>Updating configuration, please wait</source>
        <translation>Actualizando configuración, por favor espere</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1233"/>
        <source>Updating initramfs...</source>
        <translation>Actualizando initramfs...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1254"/>
        <location filename="../src/mainwindow.cpp" line="1627"/>
        <source>Updating grub...</source>
        <translation>Actualizando grub...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1285"/>
        <source>About %1</source>
        <translation>Acerca de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1286"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1288"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para seleccionar opciones comunes de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1290"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1291"/>
        <source>%1 License</source>
        <translation>%1 Licencia</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1297"/>
        <source>%1 Help</source>
        <translation>%1 Ayuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1307"/>
        <location filename="../src/mainwindow.cpp" line="1582"/>
        <source>Running in a Virtual Machine</source>
        <translation>Ejecutando en una Máquina Virtual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1308"/>
        <location filename="../src/mainwindow.cpp" line="1583"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>El sistema actual se está ejecutando en una Máquina Virtual,
La pantalla de inicio Plymouth funcionará de manera limitada, además no será posible la previsualización del tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1315"/>
        <source>Plymouth packages not installed</source>
        <translation>Paquetes de Plymouth no instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1316"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Los paquetes de Plymouth no están instalados actualmente
¿Quiere seguir adelante e instalarlos?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Imágenes (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1513"/>
        <source>Could not read the systemd boot logs.</source>
        <translation>No se pudieron leer los registros de arranque de systemd.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1514"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation>No se pudo leer los registros de arranque de systemd %1 ni el registro de reserva en %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1515"/>
        <source> from %1</source>
        <translation>desde %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1518"/>
        <source>Could not find any boot logs.</source>
        <translation>No se encontraron registros de arranque.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1519"/>
        <source>Could not find log at %1</source>
        <translation>No se encontró el registro en %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1521"/>
        <source>Log not found</source>
        <translation>Registro no encontrado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1562"/>
        <source>Preview Unavailable</source>
        <translation>Vista previa no disponible</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1563"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>La vista previa no está disponible mientras usa Wayland. Inicie una sesión X11 para la vista previa de los temas Plymouth.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>No se pudo recuperar el UUID para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Introduzca la contraseña para desbloquear la partición cifrada %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1711"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation>Contraseña cancelada o vacía para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1717"/>
        <source>Could not open %1 LUKS container</source>
        <translation>No se pudo abrir el contenedor LUKS %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1533"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="113"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation>El proceso sigue en ejecución. ¿Seguro que quiere salir?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="193"/>
        <source>Live System Detected</source>
        <translation>Sistema Live detectado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="195"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation>Actualmente está ejecutando un sistema Live. ¿Desea modificar las opciones de arranque para el sistema Live o para un sistema instalado?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="197"/>
        <source>Live System</source>
        <translation>Sistema Live</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="198"/>
        <source>Installed System</source>
        <translation>Sistema Instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="609"/>
        <source>Failed to update package sources.</source>
        <translation>Error al actualizar las fuentes de los paquetes.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="614"/>
        <source>Installing packages:</source>
        <translation>Instalando paquetes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Success</source>
        <translation>Exito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="624"/>
        <source>Bootsplash installed successfully.</source>
        <translation>Bootsplash instalado con éxito.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="652"/>
        <source>Failed to create temporary file.</source>
        <translation>Error al crear archivo temporal.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1268"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation>En este momento se está ejecutando en modo Live con la opción &quot;toram&quot;. Por favor, recuerda guardar el archivo de persistencia o remaster, de lo contrario cualquier cambio realizado se perderá.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1270"/>
        <source>Your changes have been successfully applied.</source>
        <translation>Los cambios se han aplicado con éxito.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1271"/>
        <source>Operation Complete</source>
        <translation>Operación completada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1347"/>
        <source>Select image to display in bootloader</source>
        <translation>Seleccionar imagen para mostrar en el cargador de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1526"/>
        <source>Boot Log</source>
        <translation>Registro de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1569"/>
        <source>Needs reboot</source>
        <translation>Necesita reiniciar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1570"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth se acaba de instalar, es posible que deba reiniciar antes de poder mostrar vistas previas</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1654"/>
        <source>Click to select theme</source>
        <translation>Haga clic para seleccionar el tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1665"/>
        <source>Select GRUB theme</source>
        <translation>Seleccionar tema del GRUB</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para seleccionar opciones comunes de arranque</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>No se pudo cargar %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Registro de cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>No se pudo cargar el registro de cambios.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Parece que ha iniciado sesión como root, cierre la sesión e inicie sesión como usuario normal para usar este programa.</translation>
    </message>
</context>
</TS>