<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Live környezet felismerve. Válassza ki a módosítani kívánt rendszer
 gyökér partícióját (csak Linux partíciók szerepelnek)</translation>
    </message>
    <message>
        <location filename="../dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Beállítások</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Használja az egyszerűsített menü szerkezetet, almenük nélkül</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Egyszintű menük használata (nincs almenü)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Indítás ide</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Állítsa be &apos;0&apos;-ra, a menük nélküli, azonnali indításhoz, vagy &apos;-1&apos;-re, hogy várjon végtelenségig</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Menü időtúllépés</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Kernel paraméterek</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>másodperc</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Ha engedélyezi ezt az opciót, a GRUB menüből kiválasztott elem alapértelmezettként mentésre kerül a következő indításokhoz</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Legutóbbi indítási választás mentésének engedélyezése</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>UEFI indítási opciók kezelése</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Háttér</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Kép</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Téma engedélyezése</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Indítókép</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Előnézet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Üzenetek</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Alapos részletesség</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Részletes (alap beállítás)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Korlátozott</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Megjelenítési napló</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Súgó megjelenítése</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Súgó</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Az alkalmazásról</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Névjegy...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Kilépés az alkalmazásból</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Bezárás</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Alkalmazás</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="89"/>
        <source>Still running</source>
        <translation>Még fut</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="90"/>
        <source>Process still running. Are you sure you want to quit?</source>
        <translation>A folyamat még fut. Biztos ki akar lépni?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Set timeout</source>
        <translation>Időtúllépés megadása</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Timeout in seconds:</source>
        <translation>Időtúllépés másodpercben:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="242"/>
        <location filename="../mainwindow.cpp" line="487"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <source>Timeout: %1 seconds</source>
        <translation>Időtúllépés: %1 másodperc</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="255"/>
        <location filename="../mainwindow.cpp" line="489"/>
        <location filename="../mainwindow.cpp" line="1123"/>
        <location filename="../mainwindow.cpp" line="1139"/>
        <source>Boot Next: %1</source>
        <translation>Következő Indítása: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Removal confirmation</source>
        <translation>Eltávolítás megerősítése</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Biztos, hogy törölni szeretné ezt az indítási lehetőséget?
%1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <location filename="../mainwindow.cpp" line="350"/>
        <source>Select EFI file</source>
        <translation>Válassza ki az EFI fájlt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <location filename="../mainwindow.cpp" line="351"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>EFI fájlok (*.efi, *.EFI)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="361"/>
        <location filename="../mainwindow.cpp" line="376"/>
        <location filename="../mainwindow.cpp" line="407"/>
        <location filename="../mainwindow.cpp" line="546"/>
        <location filename="../mainwindow.cpp" line="617"/>
        <source>Error</source>
        <translation>Hiba</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="362"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>Nem található a forrás csatolási pont ehhez: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>Set name</source>
        <translation>Név beállítása</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Adja meg a nevet az UEFI menü elemhez:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="376"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Hiba történt, nem sikerült az elem hozzáadása.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Indítókép telepítése, kérjük várjon</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="401"/>
        <source>Updating sources</source>
        <translation>Források frissítése</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="403"/>
        <source>Installing</source>
        <translation>Telepítés</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="407"/>
        <source>Could not install the bootsplash.</source>
        <translation>Nem sikerült az indítókép telepítése.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="491"/>
        <source>Boot Current: %1</source>
        <translation>Jelenlegi indítása: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="546"/>
        <source>Could not create a temporary folder</source>
        <translation>Ideiglenes mappa létrehozása nem sikerült</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="556"/>
        <source>Cannot continue</source>
        <translation>Nem folytatható</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="557"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Nem sikerült a chroot környezet létrehozása, nem változathatók meg az indítási opciók. Kilépés...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="617"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Hiba történt, nem sikerült az indítási sorrend mentése.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="1247"/>
        <source>Updating configuration, please wait</source>
        <translation>Beállítások frissítése, kérjük várjon</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="876"/>
        <source>Updating initramfs...</source>
        <translation>Az initramfs frissítése...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="888"/>
        <location filename="../mainwindow.cpp" line="1260"/>
        <source>Updating grub...</source>
        <translation>A GRUB frissítése...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>Done</source>
        <translation>Kész</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>Changes have been successfully applied.</source>
        <translation>A változtatások sikeresen alkalmazva.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="904"/>
        <source>About %1</source>
        <translation>%1 névjegye</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="905"/>
        <source>Version: </source>
        <translation>Verzió:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="907"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Egy program az általános indítási opciók kiválasztásához</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="909"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="910"/>
        <source>%1 License</source>
        <translation>%1 Licenc</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="931"/>
        <source>%1 Help</source>
        <translation>%1 súgó</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="940"/>
        <location filename="../mainwindow.cpp" line="1225"/>
        <source>Running in a Virtual Machine</source>
        <translation>Egy virtuális gépben fut</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="941"/>
        <location filename="../mainwindow.cpp" line="1226"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>A jelenlegi rendszer egy virtuális gépben fut,
a Pymouth indítókép korlátozott módon fog működni és nem lehetséges a téma előnézetét megjeleníteni</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="948"/>
        <source>Plymouth packages not installed</source>
        <translation>A Pymouth csomag nincs telepítve</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="949"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>A Pymouth csomagok jelenleg nincsenek telepítve.
Indulhat a telepítésük?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="972"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Képek (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1084"/>
        <source>Boot log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press any key to close</source>
        <translation type="vanished">Nyomjon meg egy billentyűt a bezáráshoz</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <source>Log not found</source>
        <translation>Napló nem található</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <source>Could not find log at </source>
        <translation>Nem található a napló:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1105"/>
        <source>Edit UEFI Boot Entries</source>
        <translation>UEFI indítási elemek szerkesztése</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1108"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>A fel és le gombokkal vagy húzd és ejtsd módszerrel rendezheti át az indítási sorrendet.
- Az elemek az indítás sorrendjében vannak.
- A szürke elemek nem aktívak.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1112"/>
        <location filename="../mainwindow.cpp" line="1166"/>
        <source>Set ac&amp;tive</source>
        <translation>Aktívvá tétel</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1113"/>
        <source>&amp;Add entry</source>
        <translation>Elem hozzáadása</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1114"/>
        <source>Boot &amp;next</source>
        <translation>Következő indítása</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1089"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <source>&amp;Close</source>
        <translation>Bezárás</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1116"/>
        <source>Move &amp;down</source>
        <translation>Mozgatás le</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1117"/>
        <source>&amp;Remove entry</source>
        <translation>Elem eltávolítása</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1118"/>
        <source>Re&amp;set next</source>
        <translation>Következő visszaállítása</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1119"/>
        <source>Change &amp;timeout</source>
        <translation>Időtúllépés megváltoztatása</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1120"/>
        <source>Move &amp;up</source>
        <translation>Mozgatás fel</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1123"/>
        <location filename="../mainwindow.cpp" line="1139"/>
        <source>not set, will boot using list order</source>
        <translation>nincs megadva, a lista sorrendjében indul</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1163"/>
        <source>Set &amp;inactive</source>
        <translation>Inaktívvá tétel</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1216"/>
        <source>Needs reboot</source>
        <translation>Újraindítás szükséges</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1217"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>A Plymouth most került telepítésre. Újraindításra lehet szükség, hogy az előnézeti kép megjeleníthető legyen</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1281"/>
        <source>Click to select theme</source>
        <translation>Kattintson a téma kiválasztásához</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="57"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Egy program az általános indítási opciók kiválasztásához</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="56"/>
        <source>License</source>
        <translation>Licenc</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="57"/>
        <location filename="../about.cpp" line="66"/>
        <source>Changelog</source>
        <translation>Változások listája</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="58"/>
        <source>Cancel</source>
        <translation>Mégsem</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="77"/>
        <source>&amp;Close</source>
        <translation>&amp;Bezárás</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="85"/>
        <location filename="../main.cpp" line="94"/>
        <source>Error</source>
        <translation>Hiba</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="86"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Úgy tűnik, hogy root felhasználóként van bejelentkezve. Jelentkezzen ki és jelentkezzen be normál felhasználóként a program használatához.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="969"/>
        <source>Select image to display in bootloader</source>
        <translation>Válassza ki a rendszerindításkor megjelenő képet</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1291"/>
        <source>Select GRUB theme</source>
        <translation>GRUB téma kiválasztása</translation>
    </message>
</context>
</TS>
