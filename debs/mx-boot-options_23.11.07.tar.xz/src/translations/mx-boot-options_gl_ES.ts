<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="gl_ES">
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Detectado sistema externo en execución. Seleccionar a partición do sistema a modificar (son exhibidas só particións Linux)</translation>
    </message>
    <message>
        <location filename="../dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opcións</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Usar estrutura de menú simplificada, sen submenús</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Usar menús simples (sen submenús)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Arranque para</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Establecer 0 para cargar de inmediato a escolla predeterminada sen exhibir o menú de opcións de arranque, ou -1 para manter o menú en espera</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Tempo de espera</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Parámetros do núcleo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>segundos</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Con está opción activada, a escolla de opción de arranque que for feita no GRUB será gardada como a nova predeterminada para os arranques futuros</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Gardar a última escolla de arranque</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Imaxe de fondo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Imaxe</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Activar tema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Máscara</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Visualizar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Mensaxes</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Presentación completa</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Presentación normal (predeterminada)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Presentación limitada</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Amosar o rexistro</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Amosar axuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Sobre esta aplicación</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Saír do aplicativo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="89"/>
        <source>Still running</source>
        <translation>Aínda executándose</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="90"/>
        <source>Process still running. Are you sure you want to quit?</source>
        <translation>O proceso segue en execución. Estás seguro de que queres saír?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Set timeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Timeout in seconds:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="242"/>
        <location filename="../mainwindow.cpp" line="487"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <source>Timeout: %1 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="255"/>
        <location filename="../mainwindow.cpp" line="489"/>
        <location filename="../mainwindow.cpp" line="1123"/>
        <location filename="../mainwindow.cpp" line="1139"/>
        <source>Boot Next: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Removal confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <location filename="../mainwindow.cpp" line="350"/>
        <source>Select EFI file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <location filename="../mainwindow.cpp" line="351"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="361"/>
        <location filename="../mainwindow.cpp" line="376"/>
        <location filename="../mainwindow.cpp" line="407"/>
        <location filename="../mainwindow.cpp" line="546"/>
        <location filename="../mainwindow.cpp" line="617"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="362"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>Set name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="376"/>
        <source>Something went wrong, could not add entry.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Instalando máscara, agarde</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="401"/>
        <source>Updating sources</source>
        <translation>Actualizando as orixes</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="403"/>
        <source>Installing</source>
        <translation>Instalando</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="407"/>
        <source>Could not install the bootsplash.</source>
        <translation>A máscara non foi instalada.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="491"/>
        <source>Boot Current: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="546"/>
        <source>Could not create a temporary folder</source>
        <translation>Non foi posíbel crear un cartafol temporal </translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="556"/>
        <source>Cannot continue</source>
        <translation>Imposible continuar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="557"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Non é posible crear un ambiente chroot. Non é posible cambiar as opcións de arranque. Saíndo...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="617"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="1247"/>
        <source>Updating configuration, please wait</source>
        <translation>Actualizando a configuración, agarda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="876"/>
        <source>Updating initramfs...</source>
        <translation>Actualizando o initramfs...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="888"/>
        <location filename="../mainwindow.cpp" line="1260"/>
        <source>Updating grub...</source>
        <translation>Actualizando o GRUB...</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>Done</source>
        <translation>Feito</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>Changes have been successfully applied.</source>
        <translation>Cambios aplicados con éxito.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="904"/>
        <source>About %1</source>
        <translation>Sobre %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="905"/>
        <source>Version: </source>
        <translation>Versión</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="907"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para seleccionar opcións de iniciación comúns</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="909"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="910"/>
        <source>%1 License</source>
        <translation>Licenza de %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="931"/>
        <source>%1 Help</source>
        <translation>Axuda para %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="940"/>
        <location filename="../mainwindow.cpp" line="1225"/>
        <source>Running in a Virtual Machine</source>
        <translation>Executándose nunha máquina virtual</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="941"/>
        <location filename="../mainwindow.cpp" line="1226"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>O sistema está a ser executado nunha máquina virtual.
A máscara do arranque Plymouth será executada con limitacións. Tamén non será posible previsualizar o tema</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="948"/>
        <source>Plymouth packages not installed</source>
        <translation>Paquetes do Plymouth non instalados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="949"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Os paquetes do Plymouth non están instalados.
Continuar e instalar estes paquetes?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="972"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Imaxes (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1084"/>
        <source>Boot log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press any key to close</source>
        <translation type="vanished">Premer calquera tecla para pechar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <source>Log not found</source>
        <translation>Rexistro non atopado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <source>Could not find log at </source>
        <translation>Non foi atopado rexistro en</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1105"/>
        <source>Edit UEFI Boot Entries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1108"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1112"/>
        <location filename="../mainwindow.cpp" line="1166"/>
        <source>Set ac&amp;tive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1113"/>
        <source>&amp;Add entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1114"/>
        <source>Boot &amp;next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1089"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1116"/>
        <source>Move &amp;down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1117"/>
        <source>&amp;Remove entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1118"/>
        <source>Re&amp;set next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1119"/>
        <source>Change &amp;timeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1120"/>
        <source>Move &amp;up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1123"/>
        <location filename="../mainwindow.cpp" line="1139"/>
        <source>not set, will boot using list order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1163"/>
        <source>Set &amp;inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1216"/>
        <source>Needs reboot</source>
        <translation>É necesario reiniciar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1217"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth acabou de ser instalado. Pode ser necesario reiniciar para exhibir as previsualizacións</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1281"/>
        <source>Click to select theme</source>
        <translation>Premer para seleccionar o tema</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="57"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para seleccionar opcións de iniciación comúns</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="56"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="57"/>
        <location filename="../about.cpp" line="66"/>
        <source>Changelog</source>
        <translation>Rexistro dos cambios</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="58"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="77"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="85"/>
        <location filename="../main.cpp" line="94"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="86"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>O usuario parece ser root; para usar este programa, pechar a sesión e iniciar sesión como usuario normal.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="969"/>
        <source>Select image to display in bootloader</source>
        <translation>Seleccionar a imaxe de fondo do cargador do arranque</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1291"/>
        <source>Select GRUB theme</source>
        <translation>Seleccionar o tema do GRUB</translation>
    </message>
</context>
</TS>
