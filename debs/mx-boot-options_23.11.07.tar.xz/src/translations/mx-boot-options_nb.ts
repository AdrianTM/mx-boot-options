<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nb">
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Oppdaget live-miljø. Velg rotpartisjonen til det
systemet du vil endre (viser kun Linux-partisjoner)</translation>
    </message>
    <message>
        <location filename="../dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Alternativer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Bruk forenklet menystruktur uten undermenyer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Bruk flate menyer (uten undermenyer)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Start opp til</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Velg «0» for å starte umiddelbart uten å vise menyen, eller «-1» for å avvente brukervalg</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Tidsavbrudd for meny</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Kjerneparametre</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>sekunder</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Slå på for å lagre valget i grub-menyen som forvalgt i framtidige oppstarter</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Lagre sist valgte oppstart</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>Behandle oppstartsalternativer for UEFI</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Bakgrunn</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Bilde</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <location filename="../mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Slå på tema</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Velkomstbilde</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Forhåndsvis</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Meldinger</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Dypt detaljert</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Detaljert (forvalgt)</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Begrenset</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Vis logg</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Vis hjelp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt + H</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Om programmet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Om …</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt + B</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Avslutt programmet</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt + N</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Bruk</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="89"/>
        <source>Still running</source>
        <translation>Kjører fortsatt</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="90"/>
        <source>Process still running. Are you sure you want to quit?</source>
        <translation>Prosess kjører fortsatt. Vil du virkelig avslutte?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Set timeout</source>
        <translation>Velg tidsavbrudd</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="237"/>
        <source>Timeout in seconds:</source>
        <translation>Tidsavbrudd i sekunder:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="242"/>
        <location filename="../mainwindow.cpp" line="487"/>
        <location filename="../mainwindow.cpp" line="1124"/>
        <source>Timeout: %1 seconds</source>
        <translation>Tidsavbrudd: %1 sekunder</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="255"/>
        <location filename="../mainwindow.cpp" line="489"/>
        <location filename="../mainwindow.cpp" line="1123"/>
        <location filename="../mainwindow.cpp" line="1139"/>
        <source>Boot Next: %1</source>
        <translation>Neste oppstart: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="263"/>
        <source>Removal confirmation</source>
        <translation>Bekreft fjerning</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="264"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>Vil du virkelig slette denne oppføringen?
%1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="347"/>
        <location filename="../mainwindow.cpp" line="350"/>
        <source>Select EFI file</source>
        <translation>Velg EFI-fil</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="348"/>
        <location filename="../mainwindow.cpp" line="351"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>EFI-filer (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="361"/>
        <location filename="../mainwindow.cpp" line="376"/>
        <location filename="../mainwindow.cpp" line="407"/>
        <location filename="../mainwindow.cpp" line="546"/>
        <location filename="../mainwindow.cpp" line="617"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="362"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>Fant ikke monteringspunkt på kilden for %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>Set name</source>
        <translation>Velg navn</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="366"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>Velg navn for UEFI-element i menyen:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="376"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>Noe gikk galt, klarte ikke legge til element.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="394"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Installerer oppstartsbilde, vennligst vent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="401"/>
        <source>Updating sources</source>
        <translation>Oppdaterer kilder</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="403"/>
        <source>Installing</source>
        <translation>Installerer</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="407"/>
        <source>Could not install the bootsplash.</source>
        <translation>Klarte ikke installere oppstartsbilde.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="491"/>
        <source>Boot Current: %1</source>
        <translation>Gjeldende oppstart: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="546"/>
        <source>Could not create a temporary folder</source>
        <translation>Klarte ikke å opprette midlertidig mappe</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="556"/>
        <source>Cannot continue</source>
        <translation>Kan ikke fortsette</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="557"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Klarte ikke opprette chroot-miljø og kan derfor ikke endre oppstartsalternativer. Avslutter …</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="617"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>Noe gikk galt, klarte ikke lagre oppstartsrekkefølge.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="823"/>
        <location filename="../mainwindow.cpp" line="1247"/>
        <source>Updating configuration, please wait</source>
        <translation>Oppdaterer oppsett – vennligst vent</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="876"/>
        <source>Updating initramfs...</source>
        <translation>Oppdaterer initramfs …</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="888"/>
        <location filename="../mainwindow.cpp" line="1260"/>
        <source>Updating grub...</source>
        <translation>Oppdaterer grub …</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>Done</source>
        <translation>Ferdig</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="892"/>
        <source>Changes have been successfully applied.</source>
        <translation>Endringene er nå tatt i bruk.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="904"/>
        <source>About %1</source>
        <translation>Om %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="905"/>
        <source>Version: </source>
        <translation>Versjon:</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="907"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Program for valg av vanlige oppstartsalternativer</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="909"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Opphavsrett (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="910"/>
        <source>%1 License</source>
        <translation>Lisens for %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="931"/>
        <source>%1 Help</source>
        <translation>Hjelpetekst for %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="940"/>
        <location filename="../mainwindow.cpp" line="1225"/>
        <source>Running in a Virtual Machine</source>
        <translation>Kjører i en virtuell maskin</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="941"/>
        <location filename="../mainwindow.cpp" line="1226"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>Systemet kjører i en virtuell maskin.
«Plymouth» oppstartsbilde har derfor begrenset virkeområde, og temaet kan ikke forhåndsvises.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="948"/>
        <source>Plymouth packages not installed</source>
        <translation>Plymouth-pakkene er ikke installerte</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="949"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Plymouth-pakkene er ikke installerte.
Vil du installere dem nå?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="972"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Bilder (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1084"/>
        <source>Boot log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Press any key to close</source>
        <translation type="vanished">Trykk en vilkårlig tast for å lukke</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <source>Log not found</source>
        <translation>Fant ikke logg</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1098"/>
        <source>Could not find log at </source>
        <translation>Fant ikke loggen på</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1105"/>
        <source>Edit UEFI Boot Entries</source>
        <translation>Rediger UEFI-elementer</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1108"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Bruk piltastene Opp/Ned eller dra og slipp for å endre oppstartsrekkefølgen.
- Elementene er listet opp i oppstartsrekkefølge.
- Grå linjer er ikke aktive.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1112"/>
        <location filename="../mainwindow.cpp" line="1166"/>
        <source>Set ac&amp;tive</source>
        <translation>Velg ak&amp;tiv</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1113"/>
        <source>&amp;Add entry</source>
        <translation>Legg til oppf&amp;øring</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1114"/>
        <source>Boot &amp;next</source>
        <translation>&amp;Neste oppstart</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1089"/>
        <location filename="../mainwindow.cpp" line="1115"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1116"/>
        <source>Move &amp;down</source>
        <translation>Flytt ne&amp;d</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1117"/>
        <source>&amp;Remove entry</source>
        <translation>Fje&amp;rn oppføring</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1118"/>
        <source>Re&amp;set next</source>
        <translation>Tilbake&amp;still neste</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1119"/>
        <source>Change &amp;timeout</source>
        <translation>Endre &amp;tidsavbrudd</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1120"/>
        <source>Move &amp;up</source>
        <translation>Fl&amp;ytt opp</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1123"/>
        <location filename="../mainwindow.cpp" line="1139"/>
        <source>not set, will boot using list order</source>
        <translation>ikke valgt, vil starte med rekkefølge som i lista</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1163"/>
        <source>Set &amp;inactive</source>
        <translation>Velg &amp;inaktiv</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1216"/>
        <source>Needs reboot</source>
        <translation>Omstart kreves</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1217"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth ble nettopp installert. Omstart kreves for å kunne forhåndsvise temaer.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1281"/>
        <source>Click to select theme</source>
        <translation>Klikk for å velge tema</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="57"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Program for valg av vanlige oppstartsalternativer</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../about.cpp" line="56"/>
        <source>License</source>
        <translation>Lisens</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="57"/>
        <location filename="../about.cpp" line="66"/>
        <source>Changelog</source>
        <translation>Endringslogg</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="58"/>
        <source>Cancel</source>
        <translation>Avbryt</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="77"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="85"/>
        <location filename="../main.cpp" line="94"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="86"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Du er innlogget som root. Vennligst logg ut, og logg inn igjen som en vanlig bruker for å bruke dette programmet.</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="95"/>
        <source>You must run this program with admin access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="969"/>
        <source>Select image to display in bootloader</source>
        <translation>Velg bilde som skal vises i oppstartslasteren</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1291"/>
        <source>Select GRUB theme</source>
        <translation>Velg Grub-tema</translation>
    </message>
</context>
</TS>
