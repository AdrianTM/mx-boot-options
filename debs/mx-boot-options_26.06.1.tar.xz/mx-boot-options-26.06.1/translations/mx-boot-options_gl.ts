<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="gl">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="204"/>
        <source>Administrator Access Required</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="205"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Detectado sistema externo en execución. Seleccionar a partición do sistema a modificar (son exhibidas só particións Linux)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opcións</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Usar estrutura de menú simplificada, sen submenús</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Usar menús simples (sen submenús)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Arranque para</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Establecer 0 para cargar de inmediato a escolla predeterminada sen exhibir o menú de opcións de arranque, ou -1 para manter o menú en espera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Tempo de espera</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Parámetros do núcleo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>segundos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Con está opción activada, a escolla de opción de arranque que for feita no GRUB será gardada como a nova predeterminada para os arranques futuros</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Gardar a última escolla de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>Xestionar opcións de arranque UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Imaxe de fondo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Imaxe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Activar tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Máscara</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Visualizar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Mensaxes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Presentación completa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Presentación normal (predeterminada)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Presentación limitada</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Amosar o rexistro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Amosar axuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Sobre esta aplicación</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Saír do aplicativo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Still running</source>
        <translation>Aínda executándose</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1175"/>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <location filename="../src/mainwindow.cpp" line="1342"/>
        <location filename="../src/mainwindow.cpp" line="2306"/>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1164"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Instalando máscara, agarde</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="245"/>
        <location filename="../src/mainwindow.cpp" line="2039"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="249"/>
        <location filename="../src/mainwindow.cpp" line="2042"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="277"/>
        <source>The live boot menu&apos;s default entry is controlled by the MX boot scripts and cannot be changed here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1171"/>
        <source>Updating sources</source>
        <translation>Actualizando as orixes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <source>Could not install the bootsplash.</source>
        <translation>A máscara non foi instalada.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1342"/>
        <source>Could not create a temporary folder</source>
        <translation>Non foi posíbel crear un cartafol temporal </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <location filename="../src/mainwindow.cpp" line="1353"/>
        <location filename="../src/mainwindow.cpp" line="1372"/>
        <source>Cannot continue</source>
        <translation>Imposible continuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1354"/>
        <location filename="../src/mainwindow.cpp" line="1373"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Non é posible crear un ambiente chroot. Non é posible cambiar as opcións de arranque. Saíndo...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1725"/>
        <location filename="../src/mainwindow.cpp" line="2219"/>
        <source>Updating configuration, please wait</source>
        <translation>Actualizando a configuración, agarda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1820"/>
        <source>Updating initramfs...</source>
        <translation>Actualizando o initramfs...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1846"/>
        <location filename="../src/mainwindow.cpp" line="2234"/>
        <source>Updating grub...</source>
        <translation>Actualizando o GRUB...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1857"/>
        <source>Refreshing live boot labels...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1886"/>
        <source>About %1</source>
        <translation>Sobre %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1887"/>
        <source>Version: </source>
        <translation>Versión: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1889"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para seleccionar opcións de iniciación comúns</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1891"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1892"/>
        <source>%1 License</source>
        <translation>Licenza de %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1898"/>
        <source>%1 Help</source>
        <translation>Axuda para %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1908"/>
        <location filename="../src/mainwindow.cpp" line="2183"/>
        <source>Running in a Virtual Machine</source>
        <translation>Executándose nunha máquina virtual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1909"/>
        <location filename="../src/mainwindow.cpp" line="2184"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>O sistema está a ser executado nunha máquina virtual.
A máscara do arranque Plymouth será executada con limitacións. Tamén non será posible previsualizar o tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1916"/>
        <source>Plymouth packages not installed</source>
        <translation>Paquetes do Plymouth non instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1917"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Os paquetes do Plymouth non están instalados.
Continuar e instalar estes paquetes?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1949"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Imaxes (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2114"/>
        <source>Could not read the systemd boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2115"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2116"/>
        <source> from %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2119"/>
        <source>Could not find any boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2120"/>
        <source>Could not find log at %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2122"/>
        <source>Log not found</source>
        <translation>Rexistro non atopado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2163"/>
        <source>Preview Unavailable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2164"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2306"/>
        <source>Could not retrieve UUID for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2314"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>Could not open %1 LUKS container</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2134"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation>O proceso segue en execución. Estás seguro de que queres saír?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="288"/>
        <source>Live System Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="290"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="292"/>
        <source>Live System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="293"/>
        <source>Installed System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1175"/>
        <source>Failed to update package sources.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1180"/>
        <source>Installing packages:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Success</source>
        <translation>Con éxito</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Bootsplash installed successfully.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>Failed to create temporary file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1869"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1871"/>
        <source>Your changes have been successfully applied.</source>
        <translation>Cambios aplicados con éxito.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1872"/>
        <source>Operation Complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1948"/>
        <source>Select image to display in bootloader</source>
        <translation>Seleccionar a imaxe de fondo do cargador do arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2127"/>
        <source>Boot Log</source>
        <translation>Rexistro de arranque</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <source>Needs reboot</source>
        <translation>É necesario reiniciar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2171"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth acabou de ser instalado. Pode ser necesario reiniciar para exhibir as previsualizacións</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2261"/>
        <source>Click to select theme</source>
        <translation>Premer para seleccionar o tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2273"/>
        <source>Select GRUB theme</source>
        <translation>Seleccionar o tema do GRUB</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para seleccionar opcións de iniciación comúns</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licenza</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Rexistro dos cambios</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Cerrar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>O usuario parece ser root; para usar este programa, pechar a sesión e iniciar sesión como usuario normal.</translation>
    </message>
</context>
</TS>