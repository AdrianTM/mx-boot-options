<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ka">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="204"/>
        <source>Administrator Access Required</source>
        <translation>საჭიროა ადმინისტრატორის წვდომა</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="205"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>ეს ოპერაცია ადმინისტრატორის პრივილეგიებს მოითხოვს. გაუშვით აპლიკაცია თავიდან და შეიყვანეთ პაროლი, როცა გკითხავენ.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>აღმოჩენილია ცოცხალი გარემო. აირჩიეთ ძირითადი დანაყოფი სისტემისთვის,
რომლის შეცვლაც გსურთ (ნაჩვენებია, მხოლოდ, Linux-ის დანაყოფები)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>დიახ</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>გაუქმება</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>მორგება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>გამარტივებული მენიუს სტრუქტურის გამოყენება ქვემენიუების გარეშე</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>ბრტყელი მენიუების გამოყენება (ქვემენიუების გარეშე)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>ჩატვირთვა სად</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>დააყენეთ &apos;0&apos;-ზე დაუყოვნებლივი ჩატვირთვისთვის მენიუს უჩვენებლად, ან &apos;-1&apos;-ზე, უსასრულო ლოდინისთვის</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>მენიუს მოლოდინის ვადა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>ბირთვის პარამეტრები</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>წამი</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>როცა ეს პარამეტრი ჩართულია, როცა grub-ის მენიუში პუნქტს აირჩევთ, ის შენახული იქნება ახალი ნაგულისხმევი მნიშვნელობის სახით მომავალში ჩატვირთვისთვის</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>ბოლოს ჩატვირთული არჩევნის შენახვის დაშვება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>UEFI-ით ჩატვირთვის პარამეტრების მართვა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>ფონის სურათი</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>გამოსახულება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>თემის ჩართვა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>გაშვების ეკრანი</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>მინიატურა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>შეტყობინებები</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>ძალიან დეტალურად</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>დეტალურად (ნაგულისხმევი პარამეტრი)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>შეზღუდული</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>ჟურნალის ჩვენება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>დახმარების ჩვენება </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>დახმარება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>ამ აპლიკაციის შესახებ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>შესახებ...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>აპლიკაციიდან გასვლა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>დახურვა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>გადატარება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Still running</source>
        <translation>ჯერ კიდევ გაშვებულია</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1175"/>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <location filename="../src/mainwindow.cpp" line="1342"/>
        <location filename="../src/mainwindow.cpp" line="2306"/>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1164"/>
        <source>Installing bootsplash, please wait</source>
        <translation>მიმდინარეობს ჩატვირთვის ეკრანის დაყენება. მოითმინეთ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="245"/>
        <location filename="../src/mainwindow.cpp" line="2039"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation>მინიატურა გათიშულია, რადგან ბირთვის ბრძანების სტრიქონში &apos;splash&apos; პარამეტრი აღმოჩენილი არა. მინიატურის ჩასართავად დაამატეთ ჩატვირთვის პარამეტრებს &apos;splash&apos; და გადატვირთეთ სისტემა.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="249"/>
        <location filename="../src/mainwindow.cpp" line="2042"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>მინიატურა გათიშულია Wayland-ზე გაშვებისას. Plymouth-ის თემების მინიატურისთვის გაუშვით X11-ის სესია.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="277"/>
        <source>The live boot menu&apos;s default entry is controlled by the MX boot scripts and cannot be changed here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1171"/>
        <source>Updating sources</source>
        <translation>წყაროების განახლება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <source>Could not install the bootsplash.</source>
        <translation>ჩატვირთვის ეკრანის დაყენება შეუძლებელია.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1342"/>
        <source>Could not create a temporary folder</source>
        <translation>დროებითი საქაღალდის შექმნა შეუძლებელია</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <location filename="../src/mainwindow.cpp" line="1353"/>
        <location filename="../src/mainwindow.cpp" line="1372"/>
        <source>Cannot continue</source>
        <translation>გაგრძელება შეუძლებელია</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation>LUKS მოწყობილობის გახსნა შეუძლებელია. მუშაობის დასრულება...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1354"/>
        <location filename="../src/mainwindow.cpp" line="1373"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>chroot გარემოს შექმნა შეუძლებელია, რადგან ჩატვირთვის პარამეტრების შეცვლა შეუძლებელია. გასვლა...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1725"/>
        <location filename="../src/mainwindow.cpp" line="2219"/>
        <source>Updating configuration, please wait</source>
        <translation>მიმდინარეობს კონფიგურაციის განახლება. მოითმინეთ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1820"/>
        <source>Updating initramfs...</source>
        <translation>Initramfs-ის განახლება...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1846"/>
        <location filename="../src/mainwindow.cpp" line="2234"/>
        <source>Updating grub...</source>
        <translation>grub-ის განახლება...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1857"/>
        <source>Refreshing live boot labels...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1886"/>
        <source>About %1</source>
        <translation>%1-ის შესახებ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1887"/>
        <source>Version: </source>
        <translation>ვერსია: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1889"/>
        <source>Program for selecting common start-up choices</source>
        <translation>პროგრამა ზოგადი გაშვების არჩევნების ასარჩევად</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1891"/>
        <source>Copyright (c) MX Linux</source>
        <translation>(c) MX Linux საავტორო ფულებები დაცულია</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1892"/>
        <source>%1 License</source>
        <translation>ლიცენზია %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1898"/>
        <source>%1 Help</source>
        <translation>%1-ის დახმარება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1908"/>
        <location filename="../src/mainwindow.cpp" line="2183"/>
        <source>Running in a Virtual Machine</source>
        <translation>გაშვებულია ვირტუალურ მანქანაში</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1909"/>
        <location filename="../src/mainwindow.cpp" line="2184"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>თქვენი სისტემა ამჟამად ვირტუალურ მანქანაზეა გაშვებული.
Plymouth-ის ჩატვირთვის მისალმების ეკრანი შეზღუდულად იმუშავებს და თქვენ თემის მინიატურებს ვერ ნახავთ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1916"/>
        <source>Plymouth packages not installed</source>
        <translation>Plymouth-ის პაკეტები დაყენებული არაა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1917"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Plymouth-ის პაკეტები ამჟამად დაყენებული არაა.
გნებავთ მათი დაყენება?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1949"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>გამოსახულებეები (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2114"/>
        <source>Could not read the systemd boot logs.</source>
        <translation>systemd-ის ჩატვირთვის ჟურნალის წაკითხვა შეუძლებელია.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2115"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation>systemd-ის ჟურნალის %1, ან სარეზერვო ჟურნალის %2 წაკითხვა შეუძლებელია.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2116"/>
        <source> from %1</source>
        <translation> %1-იდან</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2119"/>
        <source>Could not find any boot logs.</source>
        <translation>ჩატვირთვის ჟურნალი აღმოჩენილი არაა.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2120"/>
        <source>Could not find log at %1</source>
        <translation>%1-ში ჟურნალი აღმოჩენილი არაა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2122"/>
        <source>Log not found</source>
        <translation>ჟურნალი აღმოჩენილი არაა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2163"/>
        <source>Preview Unavailable</source>
        <translation>მინიატურა ხელმისაწვდომი არაა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2164"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>მინიატურა გათიშულია Wayland-ზე გაშვებისას. Plymouth-ის თემების მინიატურისთვის გაუშვით X11-ის სესია.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2306"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>%1-ისთვის UUID-ის მიღება შეუძლებელია</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2314"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>შეიყვანეთ პაროლი დაშიფრული დანაყოფის %1 განბლოკვისთვის:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation>პაროლის ჩანაწერი გაუქმებულია, ან ცარიელია %1-ისთვის</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>Could not open %1 LUKS container</source>
        <translation>LUKS-ის კონტეინერის %1 გახსნა შეუძლებელია</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2134"/>
        <source>&amp;Close</source>
        <translation>&amp;დახურვა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation>პროცესი ჯერ კიდევ გაშვებულია. მართლა გნებავთ, გახვიდეთ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="288"/>
        <source>Live System Detected</source>
        <translation>აღმოჩენილია ცოცხალი სისტემა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="290"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation>ამჟამად გაშვებული გაქვთ ცოცხალი სისტემა. გნებავთ ჩატვირთვის პარამეტრების შეცვლა ცოცხალი სისტემისთვის, თუ დაყენებული სისტემისთვის?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="292"/>
        <source>Live System</source>
        <translation>ცოცხალი სისტემა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="293"/>
        <source>Installed System</source>
        <translation>დაყენებული სისტემა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1175"/>
        <source>Failed to update package sources.</source>
        <translation>პაკეტის წყაროების განახლება ჩავარდა.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1180"/>
        <source>Installing packages:</source>
        <translation>პაკეტების დაყენება:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Success</source>
        <translation>წარმატება</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Bootsplash installed successfully.</source>
        <translation>ჩატვირთვის მისალმების ეკრანის დაყენება წარმატებულია.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>Failed to create temporary file.</source>
        <translation>დროებითი ფაილის შექმნის შეცდომა.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1869"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation>თქვენ ამჟამად გაშვებული გაქვთ ცოცხალი რეჟიმი პარამეტრით &apos;toram&apos;. დაიმახსოვრეთ, რომ შეინახოთ მუდმივობის ფაილი, ან გადააკეთოთ, არადა შეტანილი ცვლილებები დაიკარგება.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1871"/>
        <source>Your changes have been successfully applied.</source>
        <translation>თქვენი ცვლილებების გადატარება წარმატებულია.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1872"/>
        <source>Operation Complete</source>
        <translation>ოპერაცია დასრულდა</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1948"/>
        <source>Select image to display in bootloader</source>
        <translation>აირჩიეთ გამოსახულება ჩამტვირთავში საჩვენებლად</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2127"/>
        <source>Boot Log</source>
        <translation>ჩატვირთვის ჟურნალი</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <source>Needs reboot</source>
        <translation>საჭიროებს გადატვირთვას</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2171"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth ახლახან დადგა. მინიატურების საჩვენებლად, შეიძლება, გადატვირთვა დაგჭირდეთ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2261"/>
        <source>Click to select theme</source>
        <translation>დააწკაპუნეთ თემის ასარჩევად</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2273"/>
        <source>Select GRUB theme</source>
        <translation>აირჩიეთ GRUB-ის თემა</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>პროგრამა გაშვების ზოგადი პარამეტრების ასარჩევად</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>ლიცენზია</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>ცვლილებების ჟურნალი</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>გაუქმება</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;დახურვა</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>შეცდომა</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>როგორც ჩანს, root-ით ბრძანდებით შესული. ამ პროგრამის გამოსაყენებლად გადით, და შემოდით ჩვეულებრივი მომხმარებლით.</translation>
    </message>
</context>
</TS>