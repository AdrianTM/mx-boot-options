<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ko">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="204"/>
        <source>Administrator Access Required</source>
        <translation>관리자 권한 필요</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="205"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>이 기능은 관리자 권한이 필요합니다. 애플리케이션을 재시작 하고 프롬프트 창에 비밀번호를 입력하세요.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Live 환경이 감지되었습니다. 수정하려는 시스템의 루트 파티션을
선택해 주세요. (리눅스 파티션만 표시됩니다.)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>확인</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>옵션</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>하위 메뉴가 없는 간소화된 메뉴 구조 사용</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>플랫 메뉴 사용(하위 메뉴 없이)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>&apos;0&apos;으로 설정하면 메뉴를 보여주지 않고 바로 부팅하고, &apos;-1&apos;로 설정하면 사용자가 직접 선택할 때까지 기다립니다.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>초</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>이 옵션을 활성화하면 마지막으로 선택한 부트 메뉴가 이후 부팅 시 새 기본값으로 설정됩니다.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>최근 부팅 선택 기억 활성화</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>UEFI 부트 옵션 관리</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>테마 활성화</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>도움말 표시</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>도움말</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>이 애플리케이션 정보</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>About...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>종료</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>닫기</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="188"/>
        <source>Still running</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1175"/>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <location filename="../src/mainwindow.cpp" line="1342"/>
        <location filename="../src/mainwindow.cpp" line="2306"/>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>Error</source>
        <translation>에러</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1164"/>
        <source>Installing bootsplash, please wait</source>
        <translation>bootsplash를 설치하고 있습니다. 잠시 기다려 주세요.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="245"/>
        <location filename="../src/mainwindow.cpp" line="2039"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="249"/>
        <location filename="../src/mainwindow.cpp" line="2042"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="277"/>
        <source>The live boot menu&apos;s default entry is controlled by the MX boot scripts and cannot be changed here.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1171"/>
        <source>Updating sources</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1184"/>
        <source>Could not install the bootsplash.</source>
        <translation>bootsplash를 설치하지 못했습니다.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1342"/>
        <source>Could not create a temporary folder</source>
        <translation>임시 폴더를 생성할 수 없습니다.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <location filename="../src/mainwindow.cpp" line="1353"/>
        <location filename="../src/mainwindow.cpp" line="1372"/>
        <source>Cannot continue</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1348"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1354"/>
        <location filename="../src/mainwindow.cpp" line="1373"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1725"/>
        <location filename="../src/mainwindow.cpp" line="2219"/>
        <source>Updating configuration, please wait</source>
        <translation>구성 항목을 업데이트 하고 있습니다. 잠시 기다려 주세요.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1820"/>
        <source>Updating initramfs...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1846"/>
        <location filename="../src/mainwindow.cpp" line="2234"/>
        <source>Updating grub...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1857"/>
        <source>Refreshing live boot labels...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1886"/>
        <source>About %1</source>
        <translation>%1 정보</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1887"/>
        <source>Version: </source>
        <translation>버전:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1889"/>
        <source>Program for selecting common start-up choices</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1891"/>
        <source>Copyright (c) MX Linux</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1892"/>
        <source>%1 License</source>
        <translation>%1 라이센스</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1898"/>
        <source>%1 Help</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1908"/>
        <location filename="../src/mainwindow.cpp" line="2183"/>
        <source>Running in a Virtual Machine</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1909"/>
        <location filename="../src/mainwindow.cpp" line="2184"/>
        <source>You current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>현재 시스템이 가상 머신에서 실행중입니다.
Plymouth bootsplash 는 제한된 방식으로 작동되기 때문에 테마 미리 보기가 불가능할 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1916"/>
        <source>Plymouth packages not installed</source>
        <translation>Plymouth 패키지가 설치되지 않았습니다.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1917"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>현재 Plymouth 패키지가 설치되어 있지 않습니다.
패키지를 설치하고 진행하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1949"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2114"/>
        <source>Could not read the systemd boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2115"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2116"/>
        <source> from %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2119"/>
        <source>Could not find any boot logs.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2120"/>
        <source>Could not find log at %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2122"/>
        <source>Log not found</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2163"/>
        <source>Preview Unavailable</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2164"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2306"/>
        <source>Could not retrieve UUID for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2314"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2319"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2325"/>
        <source>Could not open %1 LUKS container</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2134"/>
        <source>&amp;Close</source>
        <translation>닫기(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="288"/>
        <source>Live System Detected</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="290"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="292"/>
        <source>Live System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="293"/>
        <source>Installed System</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1175"/>
        <source>Failed to update package sources.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1180"/>
        <source>Installing packages:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Success</source>
        <translation>성공</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1190"/>
        <source>Bootsplash installed successfully.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1218"/>
        <source>Failed to create temporary file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1869"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1871"/>
        <source>Your changes have been successfully applied.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1872"/>
        <source>Operation Complete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1948"/>
        <source>Select image to display in bootloader</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2127"/>
        <source>Boot Log</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2170"/>
        <source>Needs reboot</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2171"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Plymouth 설치가 완료되었습니다. 미리 보기 하려면 재부팅이 필요할 수 있습니다.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2261"/>
        <source>Click to select theme</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2273"/>
        <source>Select GRUB theme</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>로드 불가 %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>라이센스</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>변경 로그</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>취소</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>변경 로그를 불러올 수 없습니다.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>닫기(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>에러</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>루트 권한으로 로그인한 상태로 보입니다. 이 프로그램을 사용하시려면 로그아웃 후 일반 사용자로 로그인해 주세요.</translation>
    </message>
</context>
</TS>