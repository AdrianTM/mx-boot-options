const QString VERSION {"26.06.1"};
