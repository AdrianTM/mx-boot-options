<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt_BR">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="202"/>
        <source>Administrator Access Required</source>
        <translation>O acesso com as permissões de administrador é necessário</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="203"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Esta operação requer as permissões ou os privilégios de administrador. Por favor, reinicie o programa e digite a sua senha quando for solicitada.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Foi detectado o ambiente de um sistema operacional iniciado a
partir de um dispositivo executável (CD, DVD, USB, etc.). Por favor,
selecione a partição raiz (root) do sistema que você quer modificar,
apenas as partições do GNU/Linux são exibidas</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>Aceitar</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Utilizar uma de estrutura de menus simplificada sem os submenus</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Utilizar os menus condensados (sem os submenus)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Iniciar por</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Ajuste para ‘0’ para iniciar imediatamente sem exibir o menu, ou, para ‘-1’ para aguardar indefinidamente</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Tempo de espera do menu</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Parâmetros do Núcleo (Kernel)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>segundos</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Com esta opção ativada, qualquer entrada que você selecionar no menu de inicialização do Grub será salva como o novo padrão para as inicializações futuras</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Ativar o salvamento da última escolha de inicialização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>Gerenciar as Opções de Inicialização do UEFI</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Tela de fundo</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Imagem</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Ativar o tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Tela de início</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Pré-visualização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Mensagens</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Bem detalhado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Detalhado (é a configuração padrão)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Limitado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Exibir o relatório das alterações</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Exibir ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Sobre este programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Sobre...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Sair do programa</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="209"/>
        <source>Still running</source>
        <translation>Ainda está executando</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1202"/>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <location filename="../src/mainwindow.cpp" line="1245"/>
        <location filename="../src/mainwindow.cpp" line="1382"/>
        <location filename="../src/mainwindow.cpp" line="2346"/>
        <location filename="../src/mainwindow.cpp" line="2360"/>
        <location filename="../src/mainwindow.cpp" line="2366"/>
        <source>Error</source>
        <translation>Ocorreu um Erro</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1191"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Instalando a tela de inicialização. Por favor, aguarde a finalização do processo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="266"/>
        <location filename="../src/mainwindow.cpp" line="2079"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation>A pré-visualização está desativada porque o parâmetro ‘splash’ não está presente na linha de comando do kernel. Para ativar a pré-visualização, adicione o ‘splash’ aos parâmetros de inicialização, em seguida, reinicie o sistema operacional.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="270"/>
        <location filename="../src/mainwindow.cpp" line="2082"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>A pré-visualização foi desativada ao ser executada pelo servidor gráfico Wayland. Por favor, inicie uma sessão com o X11 para a pré-visualizar os temas da inicialização do sistema operacional Plymouth.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="298"/>
        <source>The live boot menu&apos;s default entry is controlled by the MX boot scripts and cannot be changed here.</source>
        <translation>O menu padrão do sistema operacional executável é controlado pelos roteiros de inicialização do MX, e não pode ser modificado por aqui.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1198"/>
        <source>Updating sources</source>
        <translation>Atualizando as fontes</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <source>Could not install the bootsplash.</source>
        <translation>Não foi possível instalar a tela de inicialização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1382"/>
        <source>Could not create a temporary folder</source>
        <translation>Não foi possível criar uma pasta temporária</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1388"/>
        <location filename="../src/mainwindow.cpp" line="1393"/>
        <location filename="../src/mainwindow.cpp" line="1412"/>
        <source>Cannot continue</source>
        <translation>Não é possível continuar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1388"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation>Não foi possível abrir o dispositivo com LUKS. Saindo do programa...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1394"/>
        <location filename="../src/mainwindow.cpp" line="1413"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Não é possível criar o ambiente ‘chroot’, não é possível alterar as opções de inicialização. Saindo do programa...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1765"/>
        <location filename="../src/mainwindow.cpp" line="2259"/>
        <source>Updating configuration, please wait</source>
        <translation>Atualizando a configuração. Por favor, aguarde a finalização do processo.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1860"/>
        <source>Updating initramfs...</source>
        <translation>Atualizando o ‘initramfs’...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1886"/>
        <location filename="../src/mainwindow.cpp" line="2274"/>
        <source>Updating grub...</source>
        <translation>Atualizando o Grub...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1897"/>
        <source>Refreshing live boot labels...</source>
        <translation>Atualizando os rótulos do sistema operacional executável...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1926"/>
        <source>About %1</source>
        <translation>Sobre o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1927"/>
        <source>Version: </source>
        <translation>Versão: </translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Programa para selecionar as opções comuns de inicialização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1931"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Direitos de Autor (c) do MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1932"/>
        <source>%1 License</source>
        <translation>Licença do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1938"/>
        <source>%1 Help</source>
        <translation>Ajuda do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1948"/>
        <location filename="../src/mainwindow.cpp" line="2223"/>
        <source>Running in a Virtual Machine</source>
        <translation>Executando em uma Máquina Virtual</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1956"/>
        <source>Plymouth packages not installed</source>
        <translation>Os pacotes do ‘Plymouth’ não estão instalados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1957"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Os pacotes do ‘Plymouth’ não estão instalados no sistema operacional.
Você quer continuar e instalar os pacotes do ‘Plymouth’?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1989"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Imagens (*.png, *.jpg, *.jpeg ou *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2154"/>
        <source>Could not read the systemd boot logs.</source>
        <translation>Não foi possível ler os registros de inicialização do SystemD.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2155"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation>Não foi possível ler os registros da inicialização do SystemD %1 ou o registro reserva %2.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2156"/>
        <source> from %1</source>
        <translation>Do %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2159"/>
        <source>Could not find any boot logs.</source>
        <translation>Não foi possível encontrar quaisquer registros de inicialização.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2160"/>
        <source>Could not find log at %1</source>
        <translation>Não foi possível encontrar os registros no %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2162"/>
        <source>Log not found</source>
        <translation>O relatório das alterações não foi encontrado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2203"/>
        <source>Preview Unavailable</source>
        <translation>A pré-visualização não está disponível.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2204"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>A pré-visualização foi desativada ao ser executada pelo servidor gráfico Wayland. Por favor, inicie uma sessão com o X11 para a pré-visualizar os temas da inicialização do sistema operacional Plymouth.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2346"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Não foi possível recuperar o UUID para o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2354"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Inserir a senha para desbloquear a partição criptografada/encriptada %1:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2360"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation>O campo de entrada da senha está cancelado ou está vazio para o %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2366"/>
        <source>Could not open %1 LUKS container</source>
        <translation>Não foi possível abrir o contêiner do LUKS %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2174"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation>Existe um outro processo que está em execução. Você realmente quer sair?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="309"/>
        <source>Live System Detected</source>
        <translation>Sistemas Executáveis que Foram Detectados</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation>Você está executando um sistema operacional a partir de um dispositivo executável (CD, DVD, USB, etc.). Você quer modificar as opções de inicialização para o sistema do dispositivo executável ou de um sistema que esteja instalado?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="313"/>
        <source>Live System</source>
        <translation>Sistema Operacional Executável</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="314"/>
        <source>Installed System</source>
        <translation>Sistema Operacional Instalado</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1202"/>
        <source>Failed to update package sources.</source>
        <translation>Ocorreu uma falha ao atualizar as fontes do pacote.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1207"/>
        <source>Installing packages:</source>
        <translation>Instalando os pacotes:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1217"/>
        <source>Success</source>
        <translation>O processo foi concluído com sucesso.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1217"/>
        <source>Bootsplash installed successfully.</source>
        <translation>A tela de inicialização foi instalada com sucesso.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1245"/>
        <source>Failed to create temporary file.</source>
        <translation>Ocorreu uma falha ao criar o arquivo temporário.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1909"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation>No momento, você está executando um sistema operacional que foi iniciado a partir de um dispositivo executável (CD, DVD, USB, etc.) com a opção ‘toram’ (para a memória RAM) ativada na inicialização. Lembre-se de salvar o arquivo de persistência ou de remasterizar o dispositivo USB executável, caso contrário, quaisquer alterações tenham sido feitas serão perdidas.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1911"/>
        <source>Your changes have been successfully applied.</source>
        <translation>As suas alterações foram aplicadas com sucesso.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1912"/>
        <source>Operation Complete</source>
        <translation>O processo foi concluído com sucesso.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1949"/>
        <location filename="../src/mainwindow.cpp" line="2224"/>
        <source>Your current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>O seu sistema atual está rodando em uma Máquina Virtual,
a tela de inicialização do ‘Plymouth’ funcionará com limitações, e você também não poderá ver a prévia do tema.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1988"/>
        <source>Select image to display in bootloader</source>
        <translation>Selecione a imagem para exibir no carregador de inicialização (bootloader)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2167"/>
        <source>Boot Log</source>
        <translation>Relatório das alterações da inicialização</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2210"/>
        <source>Needs reboot</source>
        <translation>É necessário reinicializar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2211"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>O ‘Plymouth’ foi instalado com sucesso, pode ser necessário reiniciar o sistema operacional antes de poder exibir as pré-visualizações</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2301"/>
        <source>Click to select theme</source>
        <translation>Clique para selecionar o tema</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2313"/>
        <source>Select GRUB theme</source>
        <translation>Selecionar o tema do GRUB</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>O ‘MX Boot Options’ permite alterar as opções relacionadas ao menu de inicialização do Grub (gerenciador de inicialização ou carregador de inicialização), configurar o tempo limite de exibição do menu do Grub (o padrão são 5 segundos nos sistemas operacionais instalados), configurar e reinstalar a tela de inicialização do Grub, alterar a entrada padrão de inicialização do menu do Grub, alterar a imagem e o tema do menu do Grub, ativar a seleção de inicialização nos sistemas instalados, alterar as opções de inicialização do UEFI, excluir uma ou mais entradas do menu de inicialização, entre outras opções comuns de inicialização</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>Não foi possível carregar o %1</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Licença</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Relatório das Alterações</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Não foi possível carregar o registro de alterações.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Fechar</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Ocorreu um erro</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Ao que parece, você está conectado como usuário ‘root’ (administrador). Por favor, saia da sessão e entre novamente com o usuário normal para utilizar este programa.</translation>
    </message>
</context>
</TS>