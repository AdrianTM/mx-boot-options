<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="de">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="202"/>
        <source>Administrator Access Required</source>
        <translation>Rootrechte erforderlich</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="203"/>
        <source>This operation requires administrator privileges. Please restart the application and enter your password when prompted.</source>
        <translation>Dieser Vorgang erfordert Rootrechte. Bitte starten Sie das Programm erneut und geben auf Anforderung Ihr Paßwort ein.</translation>
    </message>
</context>
<context>
    <name>CustomDialog</name>
    <message>
        <location filename="../src/dialog.cpp" line="16"/>
        <source>Live environment detected. Please select the root partition of the
 system you want to modify (only Linux partitions are displayed)</source>
        <translation>Live Umgebung festgestellt. Bitte die root-Partition des
 zu modifizierenden Systems auswählen (nur Linux-Partitionen werden angezeigt)</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="22"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../src/dialog.cpp" line="23"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="33"/>
        <source>Options</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="39"/>
        <source>Use simplified menu structure without submenus</source>
        <translation>Vereinfachte Menüstruktur ohne Untermenüs benutzen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="42"/>
        <source>Use flat menus (no submenus)</source>
        <translation>Einfache Menüs (ohne Untermenüs) benutzen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="55"/>
        <source>Boot to</source>
        <translation>Starten von</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <source>Set to &apos;0&apos; to boot immediately without displaying the menu, or to &apos;-1&apos; to wait indefinitely</source>
        <translation>Auf &apos;0&apos; setzen um sofort ohne Anzeige des Menüs zu booten oder auf &apos;-1&apos; setzen um unbefristet zu warten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="81"/>
        <source>Menu timeout</source>
        <translation>Anzeigedauer des Menüs</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="104"/>
        <source>Kernel parameters</source>
        <translation>Kernel-Parameter</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="117"/>
        <source>seconds</source>
        <translation>Sekunden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="124"/>
        <source>With this option enabled whatever entry you select from the grub boot menu will be saved as the new default for future boots</source>
        <translation>Mit dieser Option wird der im Grub-Bootmenü ausgewählte Menü-Eintrag  als Voreinstellung für den nächsten Neustart gespeichert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="127"/>
        <source>Enable saving last boot choice</source>
        <translation>Abspeichern der letzten Auswahl beim Booten aktivieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="134"/>
        <source>Manage UEFI Boot Options</source>
        <translation>UEFI-Boot-Optionen verwalten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="150"/>
        <source>Background</source>
        <translation>Hintergrund</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="168"/>
        <source>Image</source>
        <translation>Bild</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="181"/>
        <location filename="../src/mainwindow.ui" line="283"/>
        <source>Enable theme</source>
        <translation>Thema aktivieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="261"/>
        <source>Splash</source>
        <translation>Splash</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Preview</source>
        <translation>Vorschau</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="319"/>
        <source>Messages</source>
        <translation>Benachrichtigungen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="325"/>
        <source>Very detailed</source>
        <translation>Sehr ausführlich</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="332"/>
        <source>Detailed (default setting)</source>
        <translation>Ausführlich (Voreinstellung)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="342"/>
        <source>Limited</source>
        <translation>Eingeschränkt</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="358"/>
        <source>Display log</source>
        <translation>Protokoll anzeigen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="411"/>
        <source>Display help </source>
        <translation>Hilfe anzeigen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="414"/>
        <source>Help</source>
        <translation>Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="453"/>
        <source>About this application</source>
        <translation>Über diese Anwendung</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="456"/>
        <source>About...</source>
        <translation>Über...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="463"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="498"/>
        <source>Quit application</source>
        <translation>Anwendung beenden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="501"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="508"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="549"/>
        <source>Apply</source>
        <translation>Anwenden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="209"/>
        <source>Still running</source>
        <translation>Läuft noch</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1202"/>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <location filename="../src/mainwindow.cpp" line="1245"/>
        <location filename="../src/mainwindow.cpp" line="1382"/>
        <location filename="../src/mainwindow.cpp" line="2346"/>
        <location filename="../src/mainwindow.cpp" line="2360"/>
        <location filename="../src/mainwindow.cpp" line="2366"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1191"/>
        <source>Installing bootsplash, please wait</source>
        <translation>Bootsplash wird installiert, bitte warten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="266"/>
        <location filename="../src/mainwindow.cpp" line="2079"/>
        <source>Preview is disabled because &apos;splash&apos; parameter is not present in kernel command line. To enable preview, add &apos;splash&apos; to boot parameters and reboot.</source>
        <translation>Die Vorschau ist abgeschaltet, da der &apos;splash&apos; Parameter in der Befehlszeile des Kernels fehlt. Um die Vorschau zu ermöglichen &apos;splash&apos; zu den Boot-Parametern hinzufügen und den Rechner neu starten.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="270"/>
        <location filename="../src/mainwindow.cpp" line="2082"/>
        <source>Preview is disabled while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>Die Vorschau ist abgeschaltet solange Wayland läuft. Bitte eine X11 Sitzung starten um Plymouth-Themen in der Vorschau zu sehen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="298"/>
        <source>The live boot menu&apos;s default entry is controlled by the MX boot scripts and cannot be changed here.</source>
        <translation>Der voreingestellte Eintrag des Live-Boot-Menüs wird von den MX Boot-Skripten kontrolliert und kann hier nicht geändert werden.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1198"/>
        <source>Updating sources</source>
        <translation>Quellen aktualisieren</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1211"/>
        <source>Could not install the bootsplash.</source>
        <translation>Bootsplash konnte nicht installiert werden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1382"/>
        <source>Could not create a temporary folder</source>
        <translation>Es konnte kein Temporärverzeichnis angelegt werden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1388"/>
        <location filename="../src/mainwindow.cpp" line="1393"/>
        <location filename="../src/mainwindow.cpp" line="1412"/>
        <source>Cannot continue</source>
        <translation>Fortsetzen nicht möglich</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1388"/>
        <source>Cannot open LUKS device. Exiting...</source>
        <translation>LUKS Gerät nicht zu öffnen. Beenden.....</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1394"/>
        <location filename="../src/mainwindow.cpp" line="1413"/>
        <source>Cannot create chroot environment, cannot change boot options. Exiting...</source>
        <translation>Chroot-Umgebung konnte nicht erzeugt und Bootoptionen nicht geändert werden. Abbruch...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1765"/>
        <location filename="../src/mainwindow.cpp" line="2259"/>
        <source>Updating configuration, please wait</source>
        <translation>Konfiguration wird aktualisiert, bitte warten</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1860"/>
        <source>Updating initramfs...</source>
        <translation>initramfs wird aktualisiert...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1886"/>
        <location filename="../src/mainwindow.cpp" line="2274"/>
        <source>Updating grub...</source>
        <translation>Grub wird aktualisiert...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1897"/>
        <source>Refreshing live boot labels...</source>
        <translation>Erneuerung der Live-Boot-Labels...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1926"/>
        <source>About %1</source>
        <translation>Über %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1927"/>
        <source>Version: </source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1929"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Ein Programm zur Auswahl üblicher Start-Up Optionen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1931"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1932"/>
        <source>%1 License</source>
        <translation>%1 Lizenz</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1938"/>
        <source>%1 Help</source>
        <translation>%1 Hilfe</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1948"/>
        <location filename="../src/mainwindow.cpp" line="2223"/>
        <source>Running in a Virtual Machine</source>
        <translation>Ausführung in einer Oracle VM VirtualBox</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1956"/>
        <source>Plymouth packages not installed</source>
        <translation>Pakete für Plymouth sind nicht installiert</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1957"/>
        <source>Plymouth packages are not currently installed.
OK to go ahead and install them?</source>
        <translation>Plymouth packages sind derzeit nicht installiert.
OK für das Weitermachen und der Installierung dieser Pakete ?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1989"/>
        <source>Images (*.png *.jpg *.jpeg *.tga)</source>
        <translation>Bilddateien (*.png *.jpg *.jpeg *.tga)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2154"/>
        <source>Could not read the systemd boot logs.</source>
        <translation>Keine Systemd Boot-Logs zu lesen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2155"/>
        <source>Could not read the systemd boot logs%1 or the fallback log at %2.</source>
        <translation>Keine Systemd Boot-Logs auf %1 oder Fallback-Logs auf %2 lesbar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2156"/>
        <source> from %1</source>
        <translation>von %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2159"/>
        <source>Could not find any boot logs.</source>
        <translation>Keine Boot-Logs auffindbar.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2160"/>
        <source>Could not find log at %1</source>
        <translation>Keine Logs auf %1 auffindbar</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2162"/>
        <source>Log not found</source>
        <translation>Kein Protokoll gefunden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2203"/>
        <source>Preview Unavailable</source>
        <translation>Vorschau nicht möglich</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2204"/>
        <source>Preview is not available while running under Wayland. Please start an X11 session to preview Plymouth themes.</source>
        <translation>Die Vorschau ist abgeschaltet solange Wayland läuft. Bitte eine X11 Sitzung starten um Plymouth-Themen in der Vorschau zu sehen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2346"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>Die UUID für %1 konnte nicht abgerufen werden.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2354"/>
        <source>Enter password to unlock %1 encrypted partition:</source>
        <translation>Passwort eingeben, um %1 verschlüsselte Partition freizugeben :</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2360"/>
        <source>Password entry cancelled or empty for %1</source>
        <translation>Passworteingabe für %1 gestrichen oder leer</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2366"/>
        <source>Could not open %1 LUKS container</source>
        <translation>Der LUKS-Container %1 konnte nicht geöffnet werden.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2174"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="210"/>
        <source>A process is still running. Do you really want to quit?</source>
        <translation>Ein Prozess läuft noch. Möchten Sie wirklich abbrechen?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="309"/>
        <source>Live System Detected</source>
        <translation>Live-System gefunden</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="311"/>
        <source>You are currently running a live system. Would you like to modify the boot options for the live system or for an installed system?</source>
        <translation>Sie benutzen gerade ein Live-System. Möchten Sie die Boot-Optionen für das Live-System oder für ein installiertes System ändern?</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="313"/>
        <source>Live System</source>
        <translation>Live-System</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="314"/>
        <source>Installed System</source>
        <translation>Installiertes System</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1202"/>
        <source>Failed to update package sources.</source>
        <translation>Aktualisierung der Paketquellen fehlgeschlagen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1207"/>
        <source>Installing packages:</source>
        <translation>Installiere Pakete:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1217"/>
        <source>Success</source>
        <translation>Erfolg</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1217"/>
        <source>Bootsplash installed successfully.</source>
        <translation>Bootscreen wurde erfolgreich installiert.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1245"/>
        <source>Failed to create temporary file.</source>
        <translation>Temporäre Datei konnte nicht erstellt werden.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1909"/>
        <source>You are currently running in live mode with the &apos;toram&apos; option. Please remember to save the persistence file or remaster, otherwise any changes made will be lost.</source>
        <translation>Sie nutzen gerade den Live-Modus mit der Option &quot;toram&quot;. Bitte denken Sie daran, die Persistenz-Datei oder das Remaster zu speichern. Andernfalls werden alle Änderungen gelöscht.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1911"/>
        <source>Your changes have been successfully applied.</source>
        <translation>Die Änderungen wurden erfolgreich übernommen.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1912"/>
        <source>Operation Complete</source>
        <translation>Vorgang abgeschlossen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1949"/>
        <location filename="../src/mainwindow.cpp" line="2224"/>
        <source>Your current system is running in a Virtual Machine,
Plymouth bootsplash will work in a limited way, you also won&apos;t be able to preview the theme</source>
        <translation>Das derzeitige System läuft in einer Virtuellen Maschine,
Plymouth bootsplash wird nur eingeschränkt funktionieren und auch eine Vorschau des Symbolsatzes wird nicht verfügbar sein</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1988"/>
        <source>Select image to display in bootloader</source>
        <translation>Auswahl des Bildes, das im Bootlader angezeigt wird.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2167"/>
        <source>Boot Log</source>
        <translation>Boot-Protokoll</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2210"/>
        <source>Needs reboot</source>
        <translation>Neustart erforderlich</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2211"/>
        <source>Plymouth was just installed, you might need to reboot before being able to display previews</source>
        <translation>Da Plymouth gerade installiert wurde, ist möglicherweise ein Neustart erforderlich, bevor die Vorschau angezeigt werden kann.</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2301"/>
        <source>Click to select theme</source>
        <translation>Klicken, um ein Thema auszuwählen</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="2313"/>
        <source>Select GRUB theme</source>
        <translation>GRUB-Thema auswählen</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../src/main.cpp" line="64"/>
        <source>Program for selecting common start-up choices</source>
        <translation>Ein Programm zur Auswahl üblicher Systemstart-Optionen</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="71"/>
        <source>Could not load %1</source>
        <translation>%1 konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="95"/>
        <source>License</source>
        <translation>Lizenz</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="96"/>
        <location filename="../src/about.cpp" line="105"/>
        <source>Changelog</source>
        <translation>Änderungsprotokoll</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="97"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="117"/>
        <source>Could not load changelog.</source>
        <translation>Änderungsprotokoll konnte nicht geladen werden.</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="51"/>
        <location filename="../src/about.cpp" line="120"/>
        <source>&amp;Close</source>
        <translation>&amp;Schließen</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="92"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="93"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>Sie sind als Administrator am System angemeldet. Bitte melden Sie sich ab und dann als normaler Benutzer wieder an, um dieses Programm zu verwenden.</translation>
    </message>
</context>
</TS>