# CMake generated Testfile for 
# Source directory: /home/adrian/Sync/programs/qt/mx-boot-options
# Build directory: /home/adrian/Sync/programs/qt/mx-boot-options/build-review
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(mx-boot-options-tests "/home/adrian/Sync/programs/qt/mx-boot-options/build-review/mx-boot-options-tests")
set_tests_properties(mx-boot-options-tests PROPERTIES  _BACKTRACE_TRIPLES "/home/adrian/Sync/programs/qt/mx-boot-options/CMakeLists.txt;171;add_test;/home/adrian/Sync/programs/qt/mx-boot-options/CMakeLists.txt;0;")
